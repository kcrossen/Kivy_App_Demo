Graph_Index_0 = \
[
  {
    "Datapoints": [
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T22:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.62704918027062,
        "Maximum": 3.62704918027062,
        "Timestamp": "2019-03-28T23:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666658906,
        "Maximum": 3.35416666658906,
        "Timestamp": "2019-03-29T00:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T16:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-29T17:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T21:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.9062499999806,
        "Maximum": 1.9062499999806,
        "Timestamp": "2019-03-29T05:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.45833333333333,
        "Maximum": 1.45833333333333,
        "Timestamp": "2019-03-29T06:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.28125000007761,
        "Maximum": 1.28125000007761,
        "Timestamp": "2019-03-29T07:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1875,
        "Maximum": 2.1875,
        "Timestamp": "2019-03-29T04:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333327513,
        "Maximum": 1.39583333327513,
        "Timestamp": "2019-03-29T10:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T11:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62500000005821,
        "Maximum": 1.62500000005821,
        "Timestamp": "2019-03-29T12:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T09:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T16:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T19:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-28T20:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T21:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T22:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T00:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T01:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T01:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T02:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.40625,
        "Maximum": 1.40625,
        "Timestamp": "2019-03-29T08:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333294528,
        "Maximum": 0.895833333294528,
        "Timestamp": "2019-03-29T08:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T09:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666670547,
        "Maximum": 1.29166666670547,
        "Timestamp": "2019-03-29T07:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.48565573770492,
        "Maximum": 1.48565573770492,
        "Timestamp": "2019-03-29T09:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T20:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T21:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-29T00:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.40624999992239,
        "Maximum": 3.40624999992239,
        "Timestamp": "2019-03-29T02:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.958333333352736,
        "Maximum": 0.958333333352736,
        "Timestamp": "2019-03-29T09:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T16:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.52083333335274,
        "Maximum": 2.52083333335274,
        "Timestamp": "2019-03-29T14:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T16:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666668607,
        "Maximum": 2.57291666668607,
        "Timestamp": "2019-03-29T14:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666674428,
        "Maximum": 2.79166666674428,
        "Timestamp": "2019-03-28T21:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62499999996119,
        "Maximum": 1.62499999996119,
        "Timestamp": "2019-03-29T09:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-28T23:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T07:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.91666666666667,
        "Maximum": 2.91666666666667,
        "Timestamp": "2019-03-29T00:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T22:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333327513,
        "Maximum": 1.39583333327513,
        "Timestamp": "2019-03-29T06:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333331393,
        "Maximum": 1.95833333331393,
        "Timestamp": "2019-03-29T05:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333337214,
        "Maximum": 1.39583333337214,
        "Timestamp": "2019-03-29T10:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T09:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-28T22:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-29T16:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.63541666674428,
        "Maximum": 2.63541666674428,
        "Timestamp": "2019-03-28T21:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T06:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.26024590162026,
        "Maximum": 1.26024590162026,
        "Timestamp": "2019-03-29T07:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.57291666662786,
        "Maximum": 1.57291666662786,
        "Timestamp": "2019-03-29T10:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T11:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T16:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-28T23:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T00:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999994179,
        "Maximum": 1.34374999994179,
        "Timestamp": "2019-03-29T07:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T08:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T19:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T20:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T00:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-29T01:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.01041666668607,
        "Maximum": 1.01041666668607,
        "Timestamp": "2019-03-29T08:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333341094,
        "Maximum": 2.73958333341094,
        "Timestamp": "2019-03-29T14:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T20:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-28T21:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-29T01:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.1249999999806,
        "Maximum": 1.1249999999806,
        "Timestamp": "2019-03-29T07:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T02:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.3559322033701,
        "Maximum": 1.3559322033701,
        "Timestamp": "2019-03-29T08:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T09:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T15:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-29T15:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-28T22:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.7500000000388,
        "Maximum": 2.7500000000388,
        "Timestamp": "2019-03-28T22:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333391541,
        "Maximum": 0.895833333391541,
        "Timestamp": "2019-03-29T08:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T09:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.6875000000388,
        "Maximum": 3.6875000000388,
        "Timestamp": "2019-03-28T23:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666658906,
        "Maximum": 3.35416666658906,
        "Timestamp": "2019-03-29T16:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-28T22:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T17:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.9062499999806,
        "Maximum": 1.9062499999806,
        "Timestamp": "2019-03-29T05:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T05:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23770491809004,
        "Maximum": 3.23770491809004,
        "Timestamp": "2019-03-29T10:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.46398305086719,
        "Maximum": 3.46398305086719,
        "Timestamp": "2019-03-29T00:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.44791666670547,
        "Maximum": 1.44791666670547,
        "Timestamp": "2019-03-29T10:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T22:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.6875000000388,
        "Maximum": 3.6875000000388,
        "Timestamp": "2019-03-28T23:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-29T00:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.53124999994179,
        "Maximum": 3.53124999994179,
        "Timestamp": "2019-03-29T01:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-29T02:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666668607,
        "Maximum": 2.57291666668607,
        "Timestamp": "2019-03-28T21:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333329453,
        "Maximum": 3.08333333329453,
        "Timestamp": "2019-03-28T22:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T05:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333337214,
        "Maximum": 1.39583333337214,
        "Timestamp": "2019-03-29T06:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.28125000007761,
        "Maximum": 1.28125000007761,
        "Timestamp": "2019-03-29T07:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T08:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T09:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T03:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.4795081967404,
        "Maximum": 2.4795081967404,
        "Timestamp": "2019-03-29T04:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.01041666664726,
        "Maximum": 2.01041666664726,
        "Timestamp": "2019-03-29T05:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T16:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-28T18:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-28T20:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-28T22:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T00:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-29T00:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90254237282216,
        "Maximum": 2.90254237282216,
        "Timestamp": "2019-03-29T16:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-28T19:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T21:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T23:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T17:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333327513,
        "Maximum": 1.39583333327513,
        "Timestamp": "2019-03-29T10:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T12:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T06:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.01041666658906,
        "Maximum": 1.01041666658906,
        "Timestamp": "2019-03-29T08:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T17:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-29T15:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.45833333329453,
        "Maximum": 2.45833333329453,
        "Timestamp": "2019-03-29T13:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.08333333335274,
        "Maximum": 4.08333333335274,
        "Timestamp": "2019-03-29T16:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333339154,
        "Maximum": 3.08333333339154,
        "Timestamp": "2019-03-29T14:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T10:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T12:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666660846,
        "Maximum": 1.29166666660846,
        "Timestamp": "2019-03-29T07:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T09:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T11:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.61458333333333,
        "Maximum": 1.61458333333333,
        "Timestamp": "2019-03-29T12:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333294528,
        "Maximum": 0.895833333294528,
        "Timestamp": "2019-03-29T08:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-29T15:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-29T15:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.01041666668607,
        "Maximum": 1.01041666668607,
        "Timestamp": "2019-03-29T08:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333294528,
        "Maximum": 0.895833333294528,
        "Timestamp": "2019-03-29T08:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1875,
        "Maximum": 2.1875,
        "Timestamp": "2019-03-29T04:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.01041666664726,
        "Maximum": 2.01041666664726,
        "Timestamp": "2019-03-29T05:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333339154,
        "Maximum": 3.23958333339154,
        "Timestamp": "2019-03-29T00:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.80208333333333,
        "Maximum": 3.80208333333333,
        "Timestamp": "2019-03-29T01:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T21:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-28T22:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T06:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666670547,
        "Maximum": 1.29166666670547,
        "Timestamp": "2019-03-29T09:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T03:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.9062499999806,
        "Maximum": 1.9062499999806,
        "Timestamp": "2019-03-29T05:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.45833333333333,
        "Maximum": 1.45833333333333,
        "Timestamp": "2019-03-29T10:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333339154,
        "Maximum": 3.23958333339154,
        "Timestamp": "2019-03-29T17:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000007761,
        "Maximum": 2.68750000007761,
        "Timestamp": "2019-03-28T22:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-28T23:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-29T02:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T23:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-29T16:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333339154,
        "Maximum": 3.23958333339154,
        "Timestamp": "2019-03-28T19:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T22:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T16:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T19:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T23:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-28T23:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T14:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-28T20:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30508474568379,
        "Maximum": 3.30508474568379,
        "Timestamp": "2019-03-28T21:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T10:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-29T00:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.03125000007761,
        "Maximum": 5.03125000007761,
        "Timestamp": "2019-03-29T07:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666670547,
        "Maximum": 1.29166666670547,
        "Timestamp": "2019-03-29T11:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-29T14:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T15:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.45833333333333,
        "Maximum": 1.45833333333333,
        "Timestamp": "2019-03-29T11:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333335274,
        "Maximum": 1.11458333335274,
        "Timestamp": "2019-03-29T08:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-28T20:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90254237282216,
        "Maximum": 2.90254237282216,
        "Timestamp": "2019-03-28T21:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T10:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.9062499999806,
        "Maximum": 1.9062499999806,
        "Timestamp": "2019-03-29T10:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-28T22:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T23:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T08:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333337214,
        "Maximum": 1.39583333337214,
        "Timestamp": "2019-03-29T09:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T05:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T06:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.19703389828535,
        "Maximum": 1.19703389828535,
        "Timestamp": "2019-03-29T07:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T08:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29918032788794,
        "Maximum": 3.29918032788794,
        "Timestamp": "2019-03-29T17:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-29T16:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T15:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T22:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-28T23:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-29T00:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333337214,
        "Maximum": 3.58333333337214,
        "Timestamp": "2019-03-29T01:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-28T23:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T20:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T21:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333341094,
        "Maximum": 2.73958333341094,
        "Timestamp": "2019-03-28T22:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T08:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.1440677966891,
        "Maximum": 1.1440677966891,
        "Timestamp": "2019-03-29T10:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78124999996119,
        "Maximum": 1.78124999996119,
        "Timestamp": "2019-03-29T06:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T10:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.999999999961195,
        "Maximum": 0.999999999961195,
        "Timestamp": "2019-03-29T09:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T23:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-28T21:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-29T15:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666670547,
        "Maximum": 1.29166666670547,
        "Timestamp": "2019-03-29T06:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.12500000007761,
        "Maximum": 1.12500000007761,
        "Timestamp": "2019-03-29T08:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-29T17:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-29T00:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T23:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-29T16:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.8437499999806,
        "Maximum": 2.8437499999806,
        "Timestamp": "2019-03-28T22:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333335274,
        "Maximum": 1.11458333335274,
        "Timestamp": "2019-03-29T08:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T20:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.24999999992239,
        "Maximum": 3.24999999992239,
        "Timestamp": "2019-03-28T23:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T01:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T10:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18855932209309,
        "Maximum": 3.18855932209309,
        "Timestamp": "2019-03-29T00:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-29T01:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62499999996119,
        "Maximum": 1.62499999996119,
        "Timestamp": "2019-03-29T06:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.01041666664726,
        "Maximum": 2.01041666664726,
        "Timestamp": "2019-03-29T07:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-28T22:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T16:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T09:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333335274,
        "Maximum": 2.67708333335274,
        "Timestamp": "2019-03-29T15:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T21:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666658906,
        "Maximum": 1.79166666658906,
        "Timestamp": "2019-03-29T10:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.28125000007761,
        "Maximum": 1.28125000007761,
        "Timestamp": "2019-03-29T07:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.16666666668607,
        "Maximum": 1.16666666668607,
        "Timestamp": "2019-03-29T08:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-28T23:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T00:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-29T16:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T08:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T09:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T20:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666672487,
        "Maximum": 3.13541666672487,
        "Timestamp": "2019-03-28T21:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T00:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666674428,
        "Maximum": 3.57291666674428,
        "Timestamp": "2019-03-29T01:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333327513,
        "Maximum": 1.39583333327513,
        "Timestamp": "2019-03-29T06:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.1249999999806,
        "Maximum": 1.1249999999806,
        "Timestamp": "2019-03-29T09:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T06:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333337214,
        "Maximum": 1.39583333337214,
        "Timestamp": "2019-03-29T09:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T22:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T01:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-28T22:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-29T15:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.19791666668607,
        "Maximum": 3.19791666668607,
        "Timestamp": "2019-03-29T16:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.24999999998027,
        "Maximum": 1.24999999998027,
        "Timestamp": "2019-03-29T07:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.1249999999806,
        "Maximum": 1.1249999999806,
        "Timestamp": "2019-03-29T10:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T08:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666672487,
        "Maximum": 3.29166666672487,
        "Timestamp": "2019-03-29T17:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333327513,
        "Maximum": 3.58333333327513,
        "Timestamp": "2019-03-28T23:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T21:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T23:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.947916666627862,
        "Maximum": 0.947916666627862,
        "Timestamp": "2019-03-29T08:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T09:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T21:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.46398305086719,
        "Maximum": 3.46398305086719,
        "Timestamp": "2019-03-29T00:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.45833333333333,
        "Maximum": 1.45833333333333,
        "Timestamp": "2019-03-29T06:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-29T14:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T15:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T16:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333335274,
        "Maximum": 2.67708333335274,
        "Timestamp": "2019-03-28T19:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T20:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T21:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.74999999994179,
        "Maximum": 2.74999999994179,
        "Timestamp": "2019-03-28T22:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T23:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T00:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-29T01:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63729508196721,
        "Maximum": 3.63729508196721,
        "Timestamp": "2019-03-29T02:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.9062499999806,
        "Maximum": 1.9062499999806,
        "Timestamp": "2019-03-29T05:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.57291666672487,
        "Maximum": 1.57291666672487,
        "Timestamp": "2019-03-29T10:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333337214,
        "Maximum": 1.39583333337214,
        "Timestamp": "2019-03-29T11:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T06:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T08:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333391541,
        "Maximum": 0.895833333391541,
        "Timestamp": "2019-03-29T08:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333331393,
        "Maximum": 1.33333333331393,
        "Timestamp": "2019-03-29T09:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T16:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-29T14:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333335274,
        "Maximum": 2.67708333335274,
        "Timestamp": "2019-03-29T15:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T17:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-29T15:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333339154,
        "Maximum": 3.08333333339154,
        "Timestamp": "2019-03-28T23:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-29T01:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.01041666660846,
        "Maximum": 3.01041666660846,
        "Timestamp": "2019-03-28T20:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T21:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000005821,
        "Maximum": 1.78125000005821,
        "Timestamp": "2019-03-29T05:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.999999999961195,
        "Maximum": 0.999999999961195,
        "Timestamp": "2019-03-29T09:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T00:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T02:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-28T20:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T22:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.61458333333333,
        "Maximum": 1.61458333333333,
        "Timestamp": "2019-03-29T10:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666670547,
        "Maximum": 1.29166666670547,
        "Timestamp": "2019-03-29T09:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999994179,
        "Maximum": 1.34374999994179,
        "Timestamp": "2019-03-29T11:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-29T16:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-29T15:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T06:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T07:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T17:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.5312500000388,
        "Maximum": 3.5312500000388,
        "Timestamp": "2019-03-29T16:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-29T17:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.6249999999806,
        "Maximum": 3.6249999999806,
        "Timestamp": "2019-03-28T23:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-29T00:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T20:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T21:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T06:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T09:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62500000005821,
        "Maximum": 1.62500000005821,
        "Timestamp": "2019-03-29T10:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T22:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333339154,
        "Maximum": 3.23958333339154,
        "Timestamp": "2019-03-29T00:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-29T01:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T05:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T16:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-29T15:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07203389830508,
        "Maximum": 3.07203389830508,
        "Timestamp": "2019-03-28T21:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T10:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T11:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.43008474576271,
        "Maximum": 1.43008474576271,
        "Timestamp": "2019-03-29T06:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T07:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-29T16:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666670547,
        "Maximum": 1.29166666670547,
        "Timestamp": "2019-03-29T11:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T07:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T23:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-28T20:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-29T00:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000007761,
        "Maximum": 2.68750000007761,
        "Timestamp": "2019-03-28T20:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.20901639342354,
        "Maximum": 1.20901639342354,
        "Timestamp": "2019-03-29T09:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T17:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333325572,
        "Maximum": 1.73958333325572,
        "Timestamp": "2019-03-29T05:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T06:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666672487,
        "Maximum": 3.13541666672487,
        "Timestamp": "2019-03-29T01:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T21:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T09:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41188524588256,
        "Maximum": 3.41188524588256,
        "Timestamp": "2019-03-29T01:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-28T22:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.44791666660846,
        "Maximum": 1.44791666660846,
        "Timestamp": "2019-03-29T10:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T15:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T15:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666674428,
        "Maximum": 1.22916666674428,
        "Timestamp": "2019-03-29T07:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T11:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T18:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666664726,
        "Maximum": 3.57291666664726,
        "Timestamp": "2019-03-29T02:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666660846,
        "Maximum": 1.29166666660846,
        "Timestamp": "2019-03-29T07:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-29T00:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333335274,
        "Maximum": 1.11458333335274,
        "Timestamp": "2019-03-29T08:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-29T01:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T15:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333335274,
        "Maximum": 2.67708333335274,
        "Timestamp": "2019-03-29T14:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333337214,
        "Maximum": 1.39583333337214,
        "Timestamp": "2019-03-29T09:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62499999996119,
        "Maximum": 1.62499999996119,
        "Timestamp": "2019-03-29T12:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1250000000388,
        "Maximum": 2.1250000000388,
        "Timestamp": "2019-03-29T04:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T06:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-29T00:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T19:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333339154,
        "Maximum": 3.23958333339154,
        "Timestamp": "2019-03-28T17:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T14:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.24152542368935,
        "Maximum": 3.24152542368935,
        "Timestamp": "2019-03-29T00:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333325572,
        "Maximum": 2.67708333325572,
        "Timestamp": "2019-03-28T22:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T21:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-28T23:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62500000005821,
        "Maximum": 1.62500000005821,
        "Timestamp": "2019-03-29T11:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T13:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T12:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666672487,
        "Maximum": 3.13541666672487,
        "Timestamp": "2019-03-29T02:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.40625000005821,
        "Maximum": 2.40625000005821,
        "Timestamp": "2019-03-29T04:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.24795081969122,
        "Maximum": 3.24795081969122,
        "Timestamp": "2019-03-29T16:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.39583333333333,
        "Maximum": 2.39583333333333,
        "Timestamp": "2019-03-29T14:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T17:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T22:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.19791666658906,
        "Maximum": 3.19791666658906,
        "Timestamp": "2019-03-29T00:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T03:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.12499999994179,
        "Maximum": 2.12499999994179,
        "Timestamp": "2019-03-29T04:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-29T16:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T19:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.8437499999806,
        "Maximum": 2.8437499999806,
        "Timestamp": "2019-03-28T21:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333331393,
        "Maximum": 1.33333333331393,
        "Timestamp": "2019-03-29T09:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T11:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-29T02:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T10:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T00:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333325572,
        "Maximum": 2.67708333325572,
        "Timestamp": "2019-03-29T14:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T12:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T15:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T16:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-28T20:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T21:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-28T20:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T15:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T10:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.34375,
        "Maximum": 2.34375,
        "Timestamp": "2019-03-29T04:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T15:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-29T01:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.40625,
        "Maximum": 1.40625,
        "Timestamp": "2019-03-29T09:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T19:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.01041666660846,
        "Maximum": 3.01041666660846,
        "Timestamp": "2019-03-29T01:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T22:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T12:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T05:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T16:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T08:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333327513,
        "Maximum": 3.58333333327513,
        "Timestamp": "2019-03-28T18:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666660846,
        "Maximum": 2.22916666660846,
        "Timestamp": "2019-03-29T13:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.6875000000388,
        "Maximum": 3.6875000000388,
        "Timestamp": "2019-03-29T02:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T13:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.68749999994179,
        "Maximum": 3.68749999994179,
        "Timestamp": "2019-03-28T23:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T07:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T09:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.89583333325572,
        "Maximum": 1.89583333325572,
        "Timestamp": "2019-03-29T05:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T22:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.98770491807096,
        "Maximum": 1.98770491807096,
        "Timestamp": "2019-03-29T05:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T19:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T23:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999994179,
        "Maximum": 1.34374999994179,
        "Timestamp": "2019-03-29T10:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T11:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.47245762705945,
        "Maximum": 1.47245762705945,
        "Timestamp": "2019-03-29T06:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T20:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02254098360656,
        "Maximum": 3.02254098360656,
        "Timestamp": "2019-03-28T20:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T02:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-29T17:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.29166666666667,
        "Maximum": 2.29166666666667,
        "Timestamp": "2019-03-29T07:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333335274,
        "Maximum": 1.11458333335274,
        "Timestamp": "2019-03-29T07:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.44791666660846,
        "Maximum": 1.44791666660846,
        "Timestamp": "2019-03-29T11:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-28T21:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-29T03:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.19791666670547,
        "Maximum": 5.19791666670547,
        "Timestamp": "2019-03-29T04:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T08:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333391541,
        "Maximum": 0.895833333391541,
        "Timestamp": "2019-03-29T08:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T18:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999994179,
        "Maximum": 1.34374999994179,
        "Timestamp": "2019-03-29T09:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666674428,
        "Maximum": 1.22916666674428,
        "Timestamp": "2019-03-29T11:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-29T03:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T05:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333341094,
        "Maximum": 1.17708333341094,
        "Timestamp": "2019-03-29T07:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T15:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T15:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.17708333337214,
        "Maximum": 2.17708333337214,
        "Timestamp": "2019-03-29T13:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-28T19:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333327513,
        "Maximum": 3.58333333327513,
        "Timestamp": "2019-03-29T01:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333325572,
        "Maximum": 3.30208333325572,
        "Timestamp": "2019-03-29T00:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T21:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666664726,
        "Maximum": 3.57291666664726,
        "Timestamp": "2019-03-28T23:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T07:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T01:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666672487,
        "Maximum": 3.13541666672487,
        "Timestamp": "2019-03-29T03:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.01041666664726,
        "Maximum": 2.01041666664726,
        "Timestamp": "2019-03-29T04:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-29T15:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T17:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T12:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T09:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T11:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.4062499999612,
        "Maximum": 2.4062499999612,
        "Timestamp": "2019-03-29T13:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T23:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T22:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-28T20:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333325572,
        "Maximum": 3.30208333325572,
        "Timestamp": "2019-03-28T19:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1352459016966,
        "Maximum": 3.1352459016966,
        "Timestamp": "2019-03-29T00:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.07291666670547,
        "Maximum": 2.07291666670547,
        "Timestamp": "2019-03-29T05:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333337214,
        "Maximum": 3.58333333337214,
        "Timestamp": "2019-03-29T01:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.52083333335274,
        "Maximum": 2.52083333335274,
        "Timestamp": "2019-03-29T03:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-29T14:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T16:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-29T02:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T23:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T00:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666670547,
        "Maximum": 1.29166666670547,
        "Timestamp": "2019-03-29T11:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.85416666664726,
        "Maximum": 1.85416666664726,
        "Timestamp": "2019-03-29T13:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T12:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666668607,
        "Maximum": 2.57291666668607,
        "Timestamp": "2019-03-29T13:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-28T21:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.69791666662786,
        "Maximum": 4.69791666662786,
        "Timestamp": "2019-03-29T17:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-29T15:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T03:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T21:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T23:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T01:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.53688524590164,
        "Maximum": 1.53688524590164,
        "Timestamp": "2019-03-29T12:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T14:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T02:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T22:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666660846,
        "Maximum": 1.29166666660846,
        "Timestamp": "2019-03-29T09:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.72916666662786,
        "Maximum": 1.72916666662786,
        "Timestamp": "2019-03-29T06:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-28T19:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.66949152544346,
        "Maximum": 2.66949152544346,
        "Timestamp": "2019-03-29T13:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-28T20:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.80208333333333,
        "Maximum": 3.80208333333333,
        "Timestamp": "2019-03-28T23:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T10:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.75,
        "Maximum": 3.75,
        "Timestamp": "2019-03-29T04:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-29T14:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.57291666662786,
        "Maximum": 1.57291666662786,
        "Timestamp": "2019-03-29T10:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58050847455654,
        "Maximum": 3.58050847455654,
        "Timestamp": "2019-03-28T17:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T20:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T00:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T06:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.38347457627119,
        "Maximum": 2.38347457627119,
        "Timestamp": "2019-03-29T04:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T16:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333327513,
        "Maximum": 1.39583333327513,
        "Timestamp": "2019-03-29T11:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-28T21:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-28T17:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T08:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T08:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.27049180331686,
        "Maximum": 1.27049180331686,
        "Timestamp": "2019-03-29T08:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T12:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-28T18:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-28T22:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666670547,
        "Maximum": 2.22916666670547,
        "Timestamp": "2019-03-29T04:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-28T18:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333331393,
        "Maximum": 1.95833333331393,
        "Timestamp": "2019-03-29T05:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.06249999992239,
        "Maximum": 1.06249999992239,
        "Timestamp": "2019-03-29T08:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.40625,
        "Maximum": 1.40625,
        "Timestamp": "2019-03-29T09:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.46875000007761,
        "Maximum": 3.46875000007761,
        "Timestamp": "2019-03-28T18:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.91666666666667,
        "Maximum": 2.91666666666667,
        "Timestamp": "2019-03-28T19:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.72916666662786,
        "Maximum": 1.72916666662786,
        "Timestamp": "2019-03-29T05:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T06:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T05:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1352459016966,
        "Maximum": 3.1352459016966,
        "Timestamp": "2019-03-29T16:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.91666666662786,
        "Maximum": 3.91666666662786,
        "Timestamp": "2019-03-29T10:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-29T17:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T19:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-29T02:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.73958333327513,
        "Maximum": 3.73958333327513,
        "Timestamp": "2019-03-29T16:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T03:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.89583333325572,
        "Maximum": 1.89583333325572,
        "Timestamp": "2019-03-29T05:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-29T02:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.45833333339154,
        "Maximum": 2.45833333339154,
        "Timestamp": "2019-03-29T14:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.52083333335274,
        "Maximum": 2.52083333335274,
        "Timestamp": "2019-03-29T03:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T00:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333335274,
        "Maximum": 2.67708333335274,
        "Timestamp": "2019-03-28T22:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T13:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.12499999994179,
        "Maximum": 2.12499999994179,
        "Timestamp": "2019-03-29T13:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T11:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T09:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T11:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02254098360656,
        "Maximum": 3.02254098360656,
        "Timestamp": "2019-03-28T21:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-28T23:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-28T19:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-28T20:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-28T17:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T06:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T07:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-29T17:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T15:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T06:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.29166666666667,
        "Maximum": 2.29166666666667,
        "Timestamp": "2019-03-29T04:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T03:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666658906,
        "Maximum": 3.35416666658906,
        "Timestamp": "2019-03-29T01:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333341094,
        "Maximum": 3.52083333341094,
        "Timestamp": "2019-03-28T18:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-29T14:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T16:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666670547,
        "Maximum": 2.22916666670547,
        "Timestamp": "2019-03-29T13:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.7330508474379,
        "Maximum": 2.7330508474379,
        "Timestamp": "2019-03-29T15:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.51041666662786,
        "Maximum": 2.51041666662786,
        "Timestamp": "2019-03-29T13:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T23:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T00:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-29T01:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.63541666664726,
        "Maximum": 2.63541666664726,
        "Timestamp": "2019-03-29T03:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.01041666660846,
        "Maximum": 3.01041666660846,
        "Timestamp": "2019-03-28T23:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T01:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333325572,
        "Maximum": 1.11458333325572,
        "Timestamp": "2019-03-29T08:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T10:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.8586065573198,
        "Maximum": 2.8586065573198,
        "Timestamp": "2019-03-28T20:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666672487,
        "Maximum": 3.29166666672487,
        "Timestamp": "2019-03-28T18:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.01041666668607,
        "Maximum": 1.01041666668607,
        "Timestamp": "2019-03-29T09:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T10:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T20:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-28T18:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-29T03:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T17:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T15:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-29T01:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.23958333337214,
        "Maximum": 1.23958333337214,
        "Timestamp": "2019-03-29T08:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666668607,
        "Maximum": 2.57291666668607,
        "Timestamp": "2019-03-29T14:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T05:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T10:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-28T18:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.24999999992239,
        "Maximum": 3.24999999992239,
        "Timestamp": "2019-03-29T00:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07377049180328,
        "Maximum": 3.07377049180328,
        "Timestamp": "2019-03-28T20:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666662786,
        "Maximum": 3.29166666662786,
        "Timestamp": "2019-03-29T02:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-29T16:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333339154,
        "Maximum": 3.08333333339154,
        "Timestamp": "2019-03-29T15:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.999999999961195,
        "Maximum": 0.999999999961195,
        "Timestamp": "2019-03-29T08:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666674428,
        "Maximum": 1.22916666674428,
        "Timestamp": "2019-03-29T07:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T12:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666660846,
        "Maximum": 3.63541666660846,
        "Timestamp": "2019-03-28T18:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T01:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-28T22:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.60416666670547,
        "Maximum": 6.60416666670547,
        "Timestamp": "2019-03-29T03:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666660846,
        "Maximum": 1.29166666660846,
        "Timestamp": "2019-03-29T09:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666672487,
        "Maximum": 3.13541666672487,
        "Timestamp": "2019-03-29T16:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.40625000005821,
        "Maximum": 2.40625000005821,
        "Timestamp": "2019-03-29T14:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-28T19:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-29T02:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T08:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.12499999994179,
        "Maximum": 2.12499999994179,
        "Timestamp": "2019-03-29T05:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666672487,
        "Maximum": 3.29166666672487,
        "Timestamp": "2019-03-28T20:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-28T20:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T11:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.40625,
        "Maximum": 1.40625,
        "Timestamp": "2019-03-29T11:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T05:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.61458333333333,
        "Maximum": 1.61458333333333,
        "Timestamp": "2019-03-29T06:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T21:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-28T22:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.72916666662786,
        "Maximum": 1.72916666662786,
        "Timestamp": "2019-03-29T12:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T12:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-29T04:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T07:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666660846,
        "Maximum": 2.22916666660846,
        "Timestamp": "2019-03-29T04:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666660846,
        "Maximum": 1.29166666660846,
        "Timestamp": "2019-03-29T07:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.12499999994179,
        "Maximum": 2.12499999994179,
        "Timestamp": "2019-03-29T13:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000007761,
        "Maximum": 2.68750000007761,
        "Timestamp": "2019-03-28T22:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T17:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-28T23:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333327513,
        "Maximum": 3.58333333327513,
        "Timestamp": "2019-03-28T23:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.34375,
        "Maximum": 2.34375,
        "Timestamp": "2019-03-29T13:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T08:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T10:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T12:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-28T21:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T20:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.46875000007761,
        "Maximum": 3.46875000007761,
        "Timestamp": "2019-03-28T18:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T08:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666672487,
        "Maximum": 3.29166666672487,
        "Timestamp": "2019-03-29T17:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T18:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.02083333337214,
        "Maximum": 2.02083333337214,
        "Timestamp": "2019-03-29T04:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333337214,
        "Maximum": 1.39583333337214,
        "Timestamp": "2019-03-29T06:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.5312500000388,
        "Maximum": 3.5312500000388,
        "Timestamp": "2019-03-29T03:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T16:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-29T14:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333337214,
        "Maximum": 3.58333333337214,
        "Timestamp": "2019-03-29T01:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.45833333339154,
        "Maximum": 2.45833333339154,
        "Timestamp": "2019-03-29T03:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-28T22:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-29T00:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78124999996119,
        "Maximum": 1.78124999996119,
        "Timestamp": "2019-03-29T12:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T10:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T12:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.947916666627862,
        "Maximum": 0.947916666627862,
        "Timestamp": "2019-03-29T08:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.7330508474379,
        "Maximum": 2.7330508474379,
        "Timestamp": "2019-03-29T14:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-29T03:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T16:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.62499999992239,
        "Maximum": 2.62499999992239,
        "Timestamp": "2019-03-29T14:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T12:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T15:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T16:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.01041666674428,
        "Maximum": 2.01041666674428,
        "Timestamp": "2019-03-29T13:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T22:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T00:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666664726,
        "Maximum": 3.57291666664726,
        "Timestamp": "2019-03-29T02:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666672487,
        "Maximum": 3.13541666672487,
        "Timestamp": "2019-03-28T23:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.45833333335274,
        "Maximum": 3.45833333335274,
        "Timestamp": "2019-03-29T00:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.34375,
        "Maximum": 2.34375,
        "Timestamp": "2019-03-29T13:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T09:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666674428,
        "Maximum": 1.22916666674428,
        "Timestamp": "2019-03-29T11:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666660846,
        "Maximum": 3.63541666660846,
        "Timestamp": "2019-03-29T02:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.0624999999806,
        "Maximum": 2.0624999999806,
        "Timestamp": "2019-03-29T04:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T19:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.69467213112846,
        "Maximum": 2.69467213112846,
        "Timestamp": "2019-03-28T21:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-28T23:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666672487,
        "Maximum": 3.13541666672487,
        "Timestamp": "2019-03-28T17:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T07:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333341094,
        "Maximum": 3.52083333341094,
        "Timestamp": "2019-03-28T23:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.62499999992239,
        "Maximum": 2.62499999992239,
        "Timestamp": "2019-03-29T04:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T12:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0450819672322,
        "Maximum": 1.0450819672322,
        "Timestamp": "2019-03-29T09:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.26024590162026,
        "Maximum": 1.26024590162026,
        "Timestamp": "2019-03-29T07:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-28T22:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-28T19:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-28T17:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-29T17:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.29166666666667,
        "Maximum": 2.29166666666667,
        "Timestamp": "2019-03-29T13:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.01041666664726,
        "Maximum": 2.01041666664726,
        "Timestamp": "2019-03-29T05:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-29T03:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-28T23:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333294528,
        "Maximum": 0.895833333294528,
        "Timestamp": "2019-03-29T08:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T18:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-28T21:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T11:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666668607,
        "Maximum": 2.57291666668607,
        "Timestamp": "2019-03-29T14:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T08:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T17:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T00:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-28T18:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T06:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T03:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T22:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T22:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.44791666670547,
        "Maximum": 1.44791666670547,
        "Timestamp": "2019-03-29T09:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T12:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333327513,
        "Maximum": 1.39583333327513,
        "Timestamp": "2019-03-29T09:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18647540989332,
        "Maximum": 3.18647540989332,
        "Timestamp": "2019-03-28T19:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.14754098362564,
        "Maximum": 1.14754098362564,
        "Timestamp": "2019-03-29T07:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T04:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.40625000005821,
        "Maximum": 2.40625000005821,
        "Timestamp": "2019-03-29T13:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-28T19:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.1249999999806,
        "Maximum": 1.1249999999806,
        "Timestamp": "2019-03-29T08:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.29166666666667,
        "Maximum": 2.29166666666667,
        "Timestamp": "2019-03-29T04:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.73958333337214,
        "Maximum": 3.73958333337214,
        "Timestamp": "2019-03-28T23:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T18:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-28T18:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.01041666668607,
        "Maximum": 1.01041666668607,
        "Timestamp": "2019-03-29T08:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.01041666674428,
        "Maximum": 2.01041666674428,
        "Timestamp": "2019-03-29T05:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.57291666672487,
        "Maximum": 1.57291666672487,
        "Timestamp": "2019-03-29T11:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.76906779653124,
        "Maximum": 1.76906779653124,
        "Timestamp": "2019-03-29T12:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.39583333333333,
        "Maximum": 2.39583333333333,
        "Timestamp": "2019-03-29T13:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-29T14:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.85416666666667,
        "Maximum": 3.85416666666667,
        "Timestamp": "2019-03-29T02:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T03:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.17708333337214,
        "Maximum": 2.17708333337214,
        "Timestamp": "2019-03-29T04:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-28T22:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.29166666666667,
        "Maximum": 2.29166666666667,
        "Timestamp": "2019-03-29T05:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T19:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.52083333325572,
        "Maximum": 2.52083333325572,
        "Timestamp": "2019-03-28T20:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T21:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T11:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333331393,
        "Maximum": 1.95833333331393,
        "Timestamp": "2019-03-29T12:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666660846,
        "Maximum": 1.29166666660846,
        "Timestamp": "2019-03-29T09:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T10:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-29T16:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T16:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-29T15:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.62499999992239,
        "Maximum": 2.62499999992239,
        "Timestamp": "2019-03-29T14:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.34375,
        "Maximum": 2.34375,
        "Timestamp": "2019-03-29T04:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333341094,
        "Maximum": 1.95833333341094,
        "Timestamp": "2019-03-29T05:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.69791666666667,
        "Maximum": 3.69791666666667,
        "Timestamp": "2019-03-29T02:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000007761,
        "Maximum": 2.68750000007761,
        "Timestamp": "2019-03-29T03:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T17:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666672487,
        "Maximum": 3.13541666672487,
        "Timestamp": "2019-03-28T18:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T19:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T16:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.7500000000388,
        "Maximum": 2.7500000000388,
        "Timestamp": "2019-03-29T14:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T17:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.24795081969122,
        "Maximum": 3.24795081969122,
        "Timestamp": "2019-03-28T19:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-28T18:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62500000005821,
        "Maximum": 1.62500000005821,
        "Timestamp": "2019-03-29T12:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.52083333335274,
        "Maximum": 2.52083333335274,
        "Timestamp": "2019-03-29T13:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.01041666670547,
        "Maximum": 3.01041666670547,
        "Timestamp": "2019-03-29T00:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T01:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-29T00:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-29T02:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1250000000388,
        "Maximum": 2.1250000000388,
        "Timestamp": "2019-03-29T04:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T06:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333331393,
        "Maximum": 1.95833333331393,
        "Timestamp": "2019-03-29T05:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666660846,
        "Maximum": 1.29166666660846,
        "Timestamp": "2019-03-29T07:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T17:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-28T19:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62500000005821,
        "Maximum": 1.62500000005821,
        "Timestamp": "2019-03-29T12:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000007761,
        "Maximum": 2.68750000007761,
        "Timestamp": "2019-03-29T14:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T12:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.4062499999612,
        "Maximum": 2.4062499999612,
        "Timestamp": "2019-03-29T13:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T19:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333339154,
        "Maximum": 3.08333333339154,
        "Timestamp": "2019-03-28T20:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41188524588256,
        "Maximum": 3.41188524588256,
        "Timestamp": "2019-03-29T02:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-29T03:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-29T14:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333327513,
        "Maximum": 2.80208333327513,
        "Timestamp": "2019-03-28T20:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.62499999992239,
        "Maximum": 2.62499999992239,
        "Timestamp": "2019-03-29T03:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.5312500000388,
        "Maximum": 3.5312500000388,
        "Timestamp": "2019-03-29T02:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-29T03:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666660846,
        "Maximum": 2.22916666660846,
        "Timestamp": "2019-03-29T04:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.91666666666667,
        "Maximum": 2.91666666666667,
        "Timestamp": "2019-03-28T21:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666670547,
        "Maximum": 1.29166666670547,
        "Timestamp": "2019-03-29T09:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62499999996119,
        "Maximum": 1.62499999996119,
        "Timestamp": "2019-03-29T10:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T14:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-29T15:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58050847455654,
        "Maximum": 3.58050847455654,
        "Timestamp": "2019-03-28T18:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666672488,
        "Maximum": 6.26041666672488,
        "Timestamp": "2019-03-29T03:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.29166666666667,
        "Maximum": 2.29166666666667,
        "Timestamp": "2019-03-29T04:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T11:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T11:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.57291666672487,
        "Maximum": 1.57291666672487,
        "Timestamp": "2019-03-29T11:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T15:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T16:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333339154,
        "Maximum": 3.23958333339154,
        "Timestamp": "2019-03-29T00:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.35416666662786,
        "Maximum": 2.35416666662786,
        "Timestamp": "2019-03-29T04:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-28T18:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.01041666674428,
        "Maximum": 2.01041666674428,
        "Timestamp": "2019-03-29T05:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.24152542368935,
        "Maximum": 3.24152542368935,
        "Timestamp": "2019-03-28T19:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62499999996119,
        "Maximum": 1.62499999996119,
        "Timestamp": "2019-03-29T12:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-28T18:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.72916666662786,
        "Maximum": 1.72916666662786,
        "Timestamp": "2019-03-29T12:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T01:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T01:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.72916666672487,
        "Maximum": 1.72916666672487,
        "Timestamp": "2019-03-29T05:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.57291666662786,
        "Maximum": 1.57291666662786,
        "Timestamp": "2019-03-29T06:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T12:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.68749999994179,
        "Maximum": 3.68749999994179,
        "Timestamp": "2019-03-28T18:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.34375,
        "Maximum": 2.34375,
        "Timestamp": "2019-03-29T13:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T19:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T14:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.75,
        "Maximum": 3.75,
        "Timestamp": "2019-03-29T02:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T02:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333337214,
        "Maximum": 1.39583333337214,
        "Timestamp": "2019-03-29T07:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T12:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T18:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-28T19:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-28T19:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-28T20:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.63541666664726,
        "Maximum": 2.63541666664726,
        "Timestamp": "2019-03-29T15:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333325572,
        "Maximum": 3.30208333325572,
        "Timestamp": "2019-03-29T16:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-29T17:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.52083333335274,
        "Maximum": 2.52083333335274,
        "Timestamp": "2019-03-29T14:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333335274,
        "Maximum": 1.11458333335274,
        "Timestamp": "2019-03-29T11:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78124999996119,
        "Maximum": 1.78124999996119,
        "Timestamp": "2019-03-29T12:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.90625000007761,
        "Maximum": 1.90625000007761,
        "Timestamp": "2019-03-29T13:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T13:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T20:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T19:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-28T18:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-28T17:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78124999996119,
        "Maximum": 1.78124999996119,
        "Timestamp": "2019-03-29T12:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T14:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.01041666668607,
        "Maximum": 1.01041666668607,
        "Timestamp": "2019-03-29T09:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T10:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T05:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666674428,
        "Maximum": 1.22916666674428,
        "Timestamp": "2019-03-29T07:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T01:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.56250000005821,
        "Maximum": 2.56250000005821,
        "Timestamp": "2019-03-29T03:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.29166666666667,
        "Maximum": 2.29166666666667,
        "Timestamp": "2019-03-29T04:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T06:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T07:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T02:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333335274,
        "Maximum": 2.67708333335274,
        "Timestamp": "2019-03-29T14:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T11:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.12499999994179,
        "Maximum": 2.12499999994179,
        "Timestamp": "2019-03-29T13:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T09:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1875,
        "Maximum": 2.1875,
        "Timestamp": "2019-03-29T04:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-28T18:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666674428,
        "Maximum": 2.79166666674428,
        "Timestamp": "2019-03-28T20:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T01:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-29T03:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-28T21:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T23:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.80208333333333,
        "Maximum": 3.80208333333333,
        "Timestamp": "2019-03-29T02:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T03:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T22:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08401639340445,
        "Maximum": 3.08401639340445,
        "Timestamp": "2019-03-29T00:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T05:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.07291666670547,
        "Maximum": 2.07291666670547,
        "Timestamp": "2019-03-29T05:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-28T17:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-28T18:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333339154,
        "Maximum": 3.23958333339154,
        "Timestamp": "2019-03-29T00:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.46875000007761,
        "Maximum": 3.46875000007761,
        "Timestamp": "2019-03-29T01:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.17708333337214,
        "Maximum": 2.17708333337214,
        "Timestamp": "2019-03-29T04:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T21:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.97131147540984,
        "Maximum": 2.97131147540984,
        "Timestamp": "2019-03-28T22:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T15:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-29T15:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999994179,
        "Maximum": 1.34374999994179,
        "Timestamp": "2019-03-29T11:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.89583333335274,
        "Maximum": 1.89583333335274,
        "Timestamp": "2019-03-29T12:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666664726,
        "Maximum": 3.57291666664726,
        "Timestamp": "2019-03-28T18:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.36458333331393,
        "Maximum": 3.36458333331393,
        "Timestamp": "2019-03-28T17:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-29T16:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.24152542368935,
        "Maximum": 3.24152542368935,
        "Timestamp": "2019-03-29T17:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62500000005821,
        "Maximum": 1.62500000005821,
        "Timestamp": "2019-03-29T12:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T13:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333339154,
        "Maximum": 3.23958333339154,
        "Timestamp": "2019-03-28T19:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-28T20:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T05:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.44791666670547,
        "Maximum": 1.44791666670547,
        "Timestamp": "2019-03-29T06:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-29T02:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-29T03:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.89583333335274,
        "Maximum": 1.89583333335274,
        "Timestamp": "2019-03-29T12:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T09:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.26024590162026,
        "Maximum": 1.26024590162026,
        "Timestamp": "2019-03-29T10:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.4062499999612,
        "Maximum": 2.4062499999612,
        "Timestamp": "2019-03-29T13:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333327513,
        "Maximum": 1.39583333327513,
        "Timestamp": "2019-03-29T09:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.54713114759824,
        "Maximum": 1.54713114759824,
        "Timestamp": "2019-03-29T06:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666664726,
        "Maximum": 3.57291666664726,
        "Timestamp": "2019-03-29T02:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999994179,
        "Maximum": 1.34374999994179,
        "Timestamp": "2019-03-29T06:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T03:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-29T14:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.44791666670547,
        "Maximum": 1.44791666670547,
        "Timestamp": "2019-03-29T10:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90254237282216,
        "Maximum": 2.90254237282216,
        "Timestamp": "2019-03-29T14:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T11:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.7330508474379,
        "Maximum": 2.7330508474379,
        "Timestamp": "2019-03-29T03:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07203389830508,
        "Maximum": 3.07203389830508,
        "Timestamp": "2019-03-28T23:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666670547,
        "Maximum": 1.29166666670547,
        "Timestamp": "2019-03-29T07:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T04:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T20:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.85416666666667,
        "Maximum": 3.85416666666667,
        "Timestamp": "2019-03-28T17:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T21:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-29T00:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T04:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-29T01:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T21:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1875,
        "Maximum": 2.1875,
        "Timestamp": "2019-03-29T04:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T18:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-28T19:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T19:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-28T20:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T05:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.72916666662786,
        "Maximum": 1.72916666662786,
        "Timestamp": "2019-03-29T06:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-29T03:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.36065573778126,
        "Maximum": 3.36065573778126,
        "Timestamp": "2019-03-28T17:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T18:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.74999999996119,
        "Maximum": 4.74999999996119,
        "Timestamp": "2019-03-29T03:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333335274,
        "Maximum": 2.67708333335274,
        "Timestamp": "2019-03-29T14:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T13:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.30208333329453,
        "Maximum": 2.30208333329453,
        "Timestamp": "2019-03-29T13:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T01:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.96875000005821,
        "Maximum": 3.96875000005821,
        "Timestamp": "2019-03-29T02:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T03:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T15:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T11:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62499999996119,
        "Maximum": 1.62499999996119,
        "Timestamp": "2019-03-29T12:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.63541666664726,
        "Maximum": 2.63541666664726,
        "Timestamp": "2019-03-29T13:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62499999996119,
        "Maximum": 1.62499999996119,
        "Timestamp": "2019-03-29T10:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T11:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.9062499999806,
        "Maximum": 1.9062499999806,
        "Timestamp": "2019-03-29T13:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666674428,
        "Maximum": 2.79166666674428,
        "Timestamp": "2019-03-28T20:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-28T18:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-28T18:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T20:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T05:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T17:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-28T18:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666668607,
        "Maximum": 2.57291666668607,
        "Timestamp": "2019-03-29T03:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-29T14:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.9062499999806,
        "Maximum": 1.9062499999806,
        "Timestamp": "2019-03-29T13:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-29T01:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T03:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.35416666672487,
        "Maximum": 2.35416666672487,
        "Timestamp": "2019-03-29T04:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T06:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-29T02:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-29T03:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.57291666662786,
        "Maximum": 1.57291666662786,
        "Timestamp": "2019-03-29T10:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.61458333333333,
        "Maximum": 1.61458333333333,
        "Timestamp": "2019-03-29T12:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-29T15:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333341094,
        "Maximum": 2.73958333341094,
        "Timestamp": "2019-03-29T13:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333327513,
        "Maximum": 1.39583333327513,
        "Timestamp": "2019-03-29T11:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.13541666666667,
        "Maximum": 2.13541666666667,
        "Timestamp": "2019-03-29T13:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666664726,
        "Maximum": 3.57291666664726,
        "Timestamp": "2019-03-28T18:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-28T19:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T12:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.89583333335274,
        "Maximum": 1.89583333335274,
        "Timestamp": "2019-03-29T13:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-29T03:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666670547,
        "Maximum": 2.22916666670547,
        "Timestamp": "2019-03-29T04:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.46875000007761,
        "Maximum": 3.46875000007761,
        "Timestamp": "2019-03-29T01:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.75,
        "Maximum": 3.75,
        "Timestamp": "2019-03-29T02:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-28T19:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-28T20:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-28T18:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333341094,
        "Maximum": 1.95833333341094,
        "Timestamp": "2019-03-29T13:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666668607,
        "Maximum": 2.57291666668607,
        "Timestamp": "2019-03-29T14:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.16666666668607,
        "Maximum": 1.16666666668607,
        "Timestamp": "2019-03-29T11:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T06:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.9062499999806,
        "Maximum": 1.9062499999806,
        "Timestamp": "2019-03-29T05:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62500000005821,
        "Maximum": 1.62500000005821,
        "Timestamp": "2019-03-29T11:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-29T02:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-29T15:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666668607,
        "Maximum": 2.57291666668607,
        "Timestamp": "2019-03-29T03:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333339154,
        "Maximum": 3.23958333339154,
        "Timestamp": "2019-03-28T18:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T19:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333335274,
        "Maximum": 2.67708333335274,
        "Timestamp": "2019-03-29T14:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T15:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-29T03:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T12:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.36458333327513,
        "Maximum": 4.36458333327513,
        "Timestamp": "2019-03-29T04:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T12:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T19:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T19:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-29T01:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.35416666662786,
        "Maximum": 2.35416666662786,
        "Timestamp": "2019-03-29T04:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.51041666662786,
        "Maximum": 2.51041666662786,
        "Timestamp": "2019-03-29T13:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T11:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-29T14:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.8437499999806,
        "Maximum": 2.8437499999806,
        "Timestamp": "2019-03-28T20:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333327513,
        "Maximum": 3.58333333327513,
        "Timestamp": "2019-03-29T02:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.07291666660846,
        "Maximum": 2.07291666660846,
        "Timestamp": "2019-03-29T05:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T02:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T05:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333329453,
        "Maximum": 3.08333333329453,
        "Timestamp": "2019-03-28T18:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-28T18:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T11:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-29T14:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.01041666664726,
        "Maximum": 2.01041666664726,
        "Timestamp": "2019-03-29T12:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T15:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T03:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1250000000388,
        "Maximum": 2.1250000000388,
        "Timestamp": "2019-03-29T05:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T05:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.44791666670547,
        "Maximum": 1.44791666670547,
        "Timestamp": "2019-03-29T06:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.68749999994179,
        "Maximum": 3.68749999994179,
        "Timestamp": "2019-03-29T01:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.40624999992239,
        "Maximum": 3.40624999992239,
        "Timestamp": "2019-03-29T02:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-29T03:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.4687500000194,
        "Maximum": 2.4687500000194,
        "Timestamp": "2019-03-29T04:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333325572,
        "Maximum": 3.30208333325572,
        "Timestamp": "2019-03-29T00:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T14:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333337214,
        "Maximum": 1.39583333337214,
        "Timestamp": "2019-03-29T10:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.72916666662786,
        "Maximum": 1.72916666662786,
        "Timestamp": "2019-03-29T11:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.61458333333333,
        "Maximum": 1.61458333333333,
        "Timestamp": "2019-03-29T12:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.34375,
        "Maximum": 2.34375,
        "Timestamp": "2019-03-29T13:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-29T10:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666664726,
        "Maximum": 3.57291666664726,
        "Timestamp": "2019-03-29T16:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T15:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333339154,
        "Maximum": 3.08333333339154,
        "Timestamp": "2019-03-28T17:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T18:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-28T19:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-28T20:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-28T21:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.4062499999612,
        "Maximum": 2.4062499999612,
        "Timestamp": "2019-03-29T04:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333341094,
        "Maximum": 1.95833333341094,
        "Timestamp": "2019-03-29T05:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62500000005821,
        "Maximum": 1.62500000005821,
        "Timestamp": "2019-03-29T06:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T06:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T00:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-29T02:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333339154,
        "Maximum": 3.08333333339154,
        "Timestamp": "2019-03-29T01:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-29T03:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.8073770492185,
        "Maximum": 2.8073770492185,
        "Timestamp": "2019-03-29T15:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T11:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.4062499999612,
        "Maximum": 2.4062499999612,
        "Timestamp": "2019-03-29T13:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666670547,
        "Maximum": 2.22916666670547,
        "Timestamp": "2019-03-29T04:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.57291666662786,
        "Maximum": 1.57291666662786,
        "Timestamp": "2019-03-29T06:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T10:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333331393,
        "Maximum": 1.95833333331393,
        "Timestamp": "2019-03-29T10:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T16:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T12:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.52083333335274,
        "Maximum": 2.52083333335274,
        "Timestamp": "2019-03-29T14:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-28T20:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-28T18:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-28T21:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T17:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T19:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T06:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T00:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-29T02:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1875,
        "Maximum": 2.1875,
        "Timestamp": "2019-03-29T04:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-28T21:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T17:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-28T20:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.63541666664726,
        "Maximum": 2.63541666664726,
        "Timestamp": "2019-03-29T14:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.23958333337214,
        "Maximum": 1.23958333337214,
        "Timestamp": "2019-03-29T11:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.52083333335274,
        "Maximum": 2.52083333335274,
        "Timestamp": "2019-03-29T13:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T10:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T05:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T06:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-29T02:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T03:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-29T15:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T16:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-28T19:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T19:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.40625,
        "Maximum": 1.40625,
        "Timestamp": "2019-03-29T11:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62499999996119,
        "Maximum": 1.62499999996119,
        "Timestamp": "2019-03-29T12:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666672487,
        "Maximum": 3.13541666672487,
        "Timestamp": "2019-03-29T01:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666662786,
        "Maximum": 3.29166666662786,
        "Timestamp": "2019-03-29T01:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.17708333327513,
        "Maximum": 2.17708333327513,
        "Timestamp": "2019-03-29T04:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.89583333335274,
        "Maximum": 1.89583333335274,
        "Timestamp": "2019-03-29T05:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T17:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333329453,
        "Maximum": 3.08333333329453,
        "Timestamp": "2019-03-28T20:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T21:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.57291666672487,
        "Maximum": 1.57291666672487,
        "Timestamp": "2019-03-29T10:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-29T01:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.56250000005821,
        "Maximum": 2.56250000005821,
        "Timestamp": "2019-03-29T14:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T02:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666658906,
        "Maximum": 2.57291666658906,
        "Timestamp": "2019-03-29T14:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T20:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.75847457623172,
        "Maximum": 1.75847457623172,
        "Timestamp": "2019-03-29T05:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.45833333333333,
        "Maximum": 1.45833333333333,
        "Timestamp": "2019-03-29T06:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T11:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333337214,
        "Maximum": 1.39583333337214,
        "Timestamp": "2019-03-29T11:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T19:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333337214,
        "Maximum": 3.58333333337214,
        "Timestamp": "2019-03-29T02:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T15:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-29T15:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.9062499999806,
        "Maximum": 1.9062499999806,
        "Timestamp": "2019-03-29T12:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T01:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.02083333337214,
        "Maximum": 2.02083333337214,
        "Timestamp": "2019-03-29T04:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-28T19:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.8437499999806,
        "Maximum": 2.8437499999806,
        "Timestamp": "2019-03-28T20:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.45833333329453,
        "Maximum": 2.45833333329453,
        "Timestamp": "2019-03-29T14:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T10:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T05:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.68749999994179,
        "Maximum": 3.68749999994179,
        "Timestamp": "2019-03-29T01:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T19:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666662786,
        "Maximum": 3.29166666662786,
        "Timestamp": "2019-03-28T17:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-29T00:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-29T01:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.3135593219747,
        "Maximum": 1.3135593219747,
        "Timestamp": "2019-03-29T07:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T02:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T15:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.8437499999806,
        "Maximum": 2.8437499999806,
        "Timestamp": "2019-03-29T16:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.01041666668607,
        "Maximum": 1.01041666668607,
        "Timestamp": "2019-03-29T08:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T07:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T11:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.72916666662786,
        "Maximum": 1.72916666662786,
        "Timestamp": "2019-03-29T05:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-29T00:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-28T18:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-29T13:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T21:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.91666666666667,
        "Maximum": 2.91666666666667,
        "Timestamp": "2019-03-28T23:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666658906,
        "Maximum": 2.57291666658906,
        "Timestamp": "2019-03-29T14:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.07291666660846,
        "Maximum": 2.07291666660846,
        "Timestamp": "2019-03-29T04:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T06:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999994179,
        "Maximum": 1.34374999994179,
        "Timestamp": "2019-03-29T07:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.36652542376828,
        "Maximum": 1.36652542376828,
        "Timestamp": "2019-03-29T09:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T11:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T10:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.72916666662786,
        "Maximum": 1.72916666662786,
        "Timestamp": "2019-03-29T12:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.53124999994179,
        "Maximum": 3.53124999994179,
        "Timestamp": "2019-03-28T21:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.07291666660846,
        "Maximum": 2.07291666660846,
        "Timestamp": "2019-03-29T05:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T19:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333327513,
        "Maximum": 2.80208333327513,
        "Timestamp": "2019-03-28T21:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333339154,
        "Maximum": 3.08333333339154,
        "Timestamp": "2019-03-28T20:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T16:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T02:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.12499999994179,
        "Maximum": 2.12499999994179,
        "Timestamp": "2019-03-29T04:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T03:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.34375,
        "Maximum": 2.34375,
        "Timestamp": "2019-03-29T05:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-29T17:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666674428,
        "Maximum": 1.22916666674428,
        "Timestamp": "2019-03-29T07:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.01041666668607,
        "Maximum": 1.01041666668607,
        "Timestamp": "2019-03-29T09:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T07:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T09:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-28T18:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T16:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-28T21:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.61458333333333,
        "Maximum": 1.61458333333333,
        "Timestamp": "2019-03-29T11:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-29T03:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333337214,
        "Maximum": 3.58333333337214,
        "Timestamp": "2019-03-29T02:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-29T14:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333335274,
        "Maximum": 1.11458333335274,
        "Timestamp": "2019-03-29T08:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.01041666668607,
        "Maximum": 1.01041666668607,
        "Timestamp": "2019-03-29T08:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T00:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T18:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666658906,
        "Maximum": 1.79166666658906,
        "Timestamp": "2019-03-29T13:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-28T18:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-28T22:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1250000000388,
        "Maximum": 2.1250000000388,
        "Timestamp": "2019-03-29T05:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-29T15:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T09:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.8437499999806,
        "Maximum": 2.8437499999806,
        "Timestamp": "2019-03-28T19:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.91666666666667,
        "Maximum": 2.91666666666667,
        "Timestamp": "2019-03-29T14:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-29T01:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333329453,
        "Maximum": 1.67708333329453,
        "Timestamp": "2019-03-29T12:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-29T00:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.45833333333333,
        "Maximum": 1.45833333333333,
        "Timestamp": "2019-03-29T06:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T16:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T10:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78124999996119,
        "Maximum": 1.78124999996119,
        "Timestamp": "2019-03-29T06:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T22:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-28T22:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333331393,
        "Maximum": 1.95833333331393,
        "Timestamp": "2019-03-29T12:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-29T02:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-29T13:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T03:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-29T14:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-28T23:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T09:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.19672131149449,
        "Maximum": 3.19672131149449,
        "Timestamp": "2019-03-28T23:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T04:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.34375,
        "Maximum": 2.34375,
        "Timestamp": "2019-03-29T04:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T14:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333339154,
        "Maximum": 3.08333333339154,
        "Timestamp": "2019-03-28T19:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.01041666670547,
        "Maximum": 3.01041666670547,
        "Timestamp": "2019-03-29T15:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.08333333339154,
        "Maximum": 3.08333333339154,
        "Timestamp": "2019-03-28T20:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62500000005821,
        "Maximum": 1.62500000005821,
        "Timestamp": "2019-03-29T10:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29918032788794,
        "Maximum": 3.29918032788794,
        "Timestamp": "2019-03-29T00:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333335274,
        "Maximum": 1.11458333335274,
        "Timestamp": "2019-03-29T11:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-29T01:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T15:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-28T21:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T08:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333391541,
        "Maximum": 0.895833333391541,
        "Timestamp": "2019-03-29T08:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T10:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T12:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.01041666664726,
        "Maximum": 2.01041666664726,
        "Timestamp": "2019-03-29T04:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62499999996119,
        "Maximum": 1.62499999996119,
        "Timestamp": "2019-03-29T06:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-29T16:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T14:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-28T18:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T17:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-29T00:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30508474578244,
        "Maximum": 3.30508474578244,
        "Timestamp": "2019-03-29T02:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.78601694923147,
        "Maximum": 2.78601694923147,
        "Timestamp": "2019-03-28T22:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T20:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.01041666664726,
        "Maximum": 2.01041666664726,
        "Timestamp": "2019-03-29T05:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.45833333333333,
        "Maximum": 1.45833333333333,
        "Timestamp": "2019-03-29T06:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.999999999961195,
        "Maximum": 0.999999999961195,
        "Timestamp": "2019-03-29T08:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-29T02:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-29T03:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.73958333337214,
        "Maximum": 3.73958333337214,
        "Timestamp": "2019-03-29T16:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T14:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T10:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T11:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-28T21:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T00:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333327513,
        "Maximum": 3.58333333327513,
        "Timestamp": "2019-03-28T18:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-28T20:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-28T22:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T20:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T18:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.2812499999806,
        "Maximum": 1.2812499999806,
        "Timestamp": "2019-03-29T07:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.12499999994179,
        "Maximum": 2.12499999994179,
        "Timestamp": "2019-03-29T04:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T06:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T09:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.25000000007761,
        "Maximum": 4.25000000007761,
        "Timestamp": "2019-03-29T08:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.45833333333333,
        "Maximum": 1.45833333333333,
        "Timestamp": "2019-03-29T10:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T19:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-28T17:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.7330508474379,
        "Maximum": 2.7330508474379,
        "Timestamp": "2019-03-28T20:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-28T18:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.0624999999806,
        "Maximum": 2.0624999999806,
        "Timestamp": "2019-03-29T04:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333337214,
        "Maximum": 1.39583333337214,
        "Timestamp": "2019-03-29T06:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.80208333333333,
        "Maximum": 3.80208333333333,
        "Timestamp": "2019-03-29T16:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T02:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T19:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.75,
        "Maximum": 3.75,
        "Timestamp": "2019-03-28T23:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13559322029952,
        "Maximum": 3.13559322029952,
        "Timestamp": "2019-03-29T10:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.89583333335274,
        "Maximum": 1.89583333335274,
        "Timestamp": "2019-03-29T05:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T17:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.45833333329453,
        "Maximum": 2.45833333329453,
        "Timestamp": "2019-03-29T14:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T00:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-28T21:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999994179,
        "Maximum": 1.34374999994179,
        "Timestamp": "2019-03-29T11:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-29T03:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333327513,
        "Maximum": 1.39583333327513,
        "Timestamp": "2019-03-29T06:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333335274,
        "Maximum": 2.67708333335274,
        "Timestamp": "2019-03-29T13:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666670547,
        "Maximum": 1.29166666670547,
        "Timestamp": "2019-03-29T11:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T23:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-28T21:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-28T17:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T07:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-29T03:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T15:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333335274,
        "Maximum": 1.11458333335274,
        "Timestamp": "2019-03-29T09:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T12:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T01:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.40625000005821,
        "Maximum": 2.40625000005821,
        "Timestamp": "2019-03-29T04:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333331393,
        "Maximum": 1.33333333331393,
        "Timestamp": "2019-03-29T11:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T01:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333331393,
        "Maximum": 1.95833333331393,
        "Timestamp": "2019-03-29T05:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-29T15:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-29T15:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T15:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-28T21:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T01:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-29T01:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.45833333335274,
        "Maximum": 3.45833333335274,
        "Timestamp": "2019-03-28T22:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T12:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666668607,
        "Maximum": 1.79166666668607,
        "Timestamp": "2019-03-29T12:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-29T16:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-29T17:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666672487,
        "Maximum": 3.29166666672487,
        "Timestamp": "2019-03-29T02:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.62499999992239,
        "Maximum": 2.62499999992239,
        "Timestamp": "2019-03-28T22:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T02:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T09:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-28T23:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1875,
        "Maximum": 2.1875,
        "Timestamp": "2019-03-29T13:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666658906,
        "Maximum": 1.79166666658906,
        "Timestamp": "2019-03-29T12:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T19:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.40625000005821,
        "Maximum": 2.40625000005821,
        "Timestamp": "2019-03-29T13:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T22:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-29T17:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-29T15:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.29166666666667,
        "Maximum": 2.29166666666667,
        "Timestamp": "2019-03-29T04:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.61458333333333,
        "Maximum": 1.61458333333333,
        "Timestamp": "2019-03-29T06:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-29T01:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-29T15:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.64344262293174,
        "Maximum": 2.64344262293174,
        "Timestamp": "2019-03-29T13:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T02:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666658906,
        "Maximum": 3.35416666658906,
        "Timestamp": "2019-03-29T01:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.69791666666667,
        "Maximum": 3.69791666666667,
        "Timestamp": "2019-03-28T23:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T12:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.44791666670547,
        "Maximum": 1.44791666670547,
        "Timestamp": "2019-03-29T10:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.06249999992239,
        "Maximum": 1.06249999992239,
        "Timestamp": "2019-03-29T10:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.07291666664726,
        "Maximum": 1.07291666664726,
        "Timestamp": "2019-03-29T08:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T22:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T20:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29918032788794,
        "Maximum": 3.29918032788794,
        "Timestamp": "2019-03-28T18:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T19:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.1249999999806,
        "Maximum": 1.1249999999806,
        "Timestamp": "2019-03-29T08:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T18:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.32172131151358,
        "Maximum": 1.32172131151358,
        "Timestamp": "2019-03-29T06:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-29T16:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.52083333325572,
        "Maximum": 2.52083333325572,
        "Timestamp": "2019-03-29T03:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333331393,
        "Maximum": 1.95833333331393,
        "Timestamp": "2019-03-29T05:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.29166666666667,
        "Maximum": 2.29166666666667,
        "Timestamp": "2019-03-29T04:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.9062499999806,
        "Maximum": 1.9062499999806,
        "Timestamp": "2019-03-29T06:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T10:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T12:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-28T20:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-28T22:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-28T21:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-28T23:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000003881,
        "Maximum": 1.34375000003881,
        "Timestamp": "2019-03-29T11:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.89583333335274,
        "Maximum": 1.89583333335274,
        "Timestamp": "2019-03-29T13:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.28125000007761,
        "Maximum": 1.28125000007761,
        "Timestamp": "2019-03-29T07:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T06:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.63541666664726,
        "Maximum": 2.63541666664726,
        "Timestamp": "2019-03-29T03:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.07291666660846,
        "Maximum": 2.07291666660846,
        "Timestamp": "2019-03-29T05:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333335274,
        "Maximum": 1.11458333335274,
        "Timestamp": "2019-03-29T08:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.45833333333333,
        "Maximum": 1.45833333333333,
        "Timestamp": "2019-03-29T06:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07291666666667,
        "Maximum": 3.07291666666667,
        "Timestamp": "2019-03-28T17:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-28T18:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T07:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.12499999994179,
        "Maximum": 2.12499999994179,
        "Timestamp": "2019-03-29T13:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.07291666660846,
        "Maximum": 2.07291666660846,
        "Timestamp": "2019-03-29T05:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T11:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-28T23:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90624999994179,
        "Maximum": 2.90624999994179,
        "Timestamp": "2019-03-28T21:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-29T03:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.44791666670547,
        "Maximum": 1.44791666670547,
        "Timestamp": "2019-03-29T09:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-29T14:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T06:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.89583333325572,
        "Maximum": 1.89583333325572,
        "Timestamp": "2019-03-29T13:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-28T19:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.90983606561194,
        "Maximum": 2.90983606561194,
        "Timestamp": "2019-03-29T00:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T22:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.4687500000194,
        "Maximum": 2.4687500000194,
        "Timestamp": "2019-03-29T04:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18750000005821,
        "Maximum": 3.18750000005821,
        "Timestamp": "2019-03-28T20:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.5625,
        "Maximum": 1.5625,
        "Timestamp": "2019-03-29T10:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T15:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.16666666668607,
        "Maximum": 1.16666666668607,
        "Timestamp": "2019-03-29T07:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1250000000388,
        "Maximum": 2.1250000000388,
        "Timestamp": "2019-03-29T13:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-29T01:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.69791666666667,
        "Maximum": 3.69791666666667,
        "Timestamp": "2019-03-28T23:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.46875000007761,
        "Maximum": 3.46875000007761,
        "Timestamp": "2019-03-29T02:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T08:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333337214,
        "Maximum": 3.58333333337214,
        "Timestamp": "2019-03-28T18:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666670547,
        "Maximum": 2.85416666670547,
        "Timestamp": "2019-03-29T16:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.74999999994179,
        "Maximum": 2.74999999994179,
        "Timestamp": "2019-03-29T14:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.64344262302716,
        "Maximum": 2.64344262302716,
        "Timestamp": "2019-03-29T14:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T23:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41666666664726,
        "Maximum": 3.41666666664726,
        "Timestamp": "2019-03-29T02:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333335274,
        "Maximum": 1.11458333335274,
        "Timestamp": "2019-03-29T08:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.36458333331393,
        "Maximum": 3.36458333331393,
        "Timestamp": "2019-03-29T00:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.58196721313384,
        "Maximum": 2.58196721313384,
        "Timestamp": "2019-03-29T03:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.24999999998027,
        "Maximum": 1.24999999998027,
        "Timestamp": "2019-03-29T09:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-28T18:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-28T19:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-29T15:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-29T15:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-29T01:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666670547,
        "Maximum": 1.29166666670547,
        "Timestamp": "2019-03-29T09:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.5805084746552,
        "Maximum": 3.5805084746552,
        "Timestamp": "2019-03-29T01:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.73958333335274,
        "Maximum": 1.73958333335274,
        "Timestamp": "2019-03-29T10:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T19:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.63541666664726,
        "Maximum": 2.63541666664726,
        "Timestamp": "2019-03-28T20:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63541666670547,
        "Maximum": 3.63541666670547,
        "Timestamp": "2019-03-29T02:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52754237286163,
        "Maximum": 3.52754237286163,
        "Timestamp": "2019-03-29T16:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.17708333331393,
        "Maximum": 1.17708333331393,
        "Timestamp": "2019-03-29T07:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.9062499999806,
        "Maximum": 1.9062499999806,
        "Timestamp": "2019-03-29T12:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333327513,
        "Maximum": 1.39583333327513,
        "Timestamp": "2019-03-29T09:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T11:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-28T21:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666668607,
        "Maximum": 2.57291666668607,
        "Timestamp": "2019-03-28T22:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333337214,
        "Maximum": 2.95833333337214,
        "Timestamp": "2019-03-28T17:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-28T19:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.24999999998027,
        "Maximum": 1.24999999998027,
        "Timestamp": "2019-03-29T09:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4062500000194,
        "Maximum": 3.4062500000194,
        "Timestamp": "2019-03-28T19:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37499999996119,
        "Maximum": 5.37499999996119,
        "Timestamp": "2019-03-29T03:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.89583333335274,
        "Maximum": 1.89583333335274,
        "Timestamp": "2019-03-29T05:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.29166666660846,
        "Maximum": 1.29166666660846,
        "Timestamp": "2019-03-29T07:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-29T16:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.79166666664726,
        "Maximum": 2.79166666664726,
        "Timestamp": "2019-03-29T15:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333325572,
        "Maximum": 3.30208333325572,
        "Timestamp": "2019-03-29T01:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666662786,
        "Maximum": 3.29166666662786,
        "Timestamp": "2019-03-29T02:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.1875,
        "Maximum": 2.1875,
        "Timestamp": "2019-03-29T04:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.75,
        "Maximum": 3.75,
        "Timestamp": "2019-03-28T23:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.29166666666667,
        "Maximum": 2.29166666666667,
        "Timestamp": "2019-03-29T13:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.39583333327513,
        "Maximum": 1.39583333327513,
        "Timestamp": "2019-03-29T09:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T11:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.16666666668607,
        "Maximum": 1.16666666668607,
        "Timestamp": "2019-03-29T07:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.8437500000194,
        "Maximum": 1.8437500000194,
        "Timestamp": "2019-03-29T13:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.95833333327513,
        "Maximum": 2.95833333327513,
        "Timestamp": "2019-03-28T17:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T19:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.45833333339154,
        "Maximum": 2.45833333339154,
        "Timestamp": "2019-03-29T13:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6250000000194,
        "Maximum": 2.6250000000194,
        "Timestamp": "2019-03-28T21:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.96875,
        "Maximum": 2.96875,
        "Timestamp": "2019-03-28T22:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T17:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666672487,
        "Maximum": 3.29166666672487,
        "Timestamp": "2019-03-28T21:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T23:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666664726,
        "Maximum": 1.22916666664726,
        "Timestamp": "2019-03-29T10:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.62499999996119,
        "Maximum": 1.62499999996119,
        "Timestamp": "2019-03-29T11:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0450819672322,
        "Maximum": 1.0450819672322,
        "Timestamp": "2019-03-29T08:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-28T18:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-28T18:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.91666666666667,
        "Maximum": 2.91666666666667,
        "Timestamp": "2019-03-28T20:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.08050847449735,
        "Maximum": 1.08050847449735,
        "Timestamp": "2019-03-29T08:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T03:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.02083333337214,
        "Maximum": 2.02083333337214,
        "Timestamp": "2019-03-29T04:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.44791666670547,
        "Maximum": 1.44791666670547,
        "Timestamp": "2019-03-29T06:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.22916666674428,
        "Maximum": 1.22916666674428,
        "Timestamp": "2019-03-29T07:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.947916666724874,
        "Maximum": 0.947916666724874,
        "Timestamp": "2019-03-29T09:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-29T03:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.95833333331393,
        "Maximum": 1.95833333331393,
        "Timestamp": "2019-03-29T05:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-28T18:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T17:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666668607,
        "Maximum": 3.35416666668607,
        "Timestamp": "2019-03-29T00:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.40625,
        "Maximum": 1.40625,
        "Timestamp": "2019-03-29T06:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.63541666664726,
        "Maximum": 2.63541666664726,
        "Timestamp": "2019-03-29T13:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.9062500000388,
        "Maximum": 2.9062500000388,
        "Timestamp": "2019-03-29T03:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.85416666666667,
        "Maximum": 3.85416666666667,
        "Timestamp": "2019-03-29T10:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T19:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T23:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.51041666666667,
        "Maximum": 1.51041666666667,
        "Timestamp": "2019-03-29T12:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666662786,
        "Maximum": 3.13541666662786,
        "Timestamp": "2019-03-29T16:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666670547,
        "Maximum": 2.22916666670547,
        "Timestamp": "2019-03-29T04:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.74999999994081,
        "Maximum": 3.74999999994081,
        "Timestamp": "2019-03-29T02:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333341094,
        "Maximum": 2.73958333341094,
        "Timestamp": "2019-03-28T22:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.0625000000194,
        "Maximum": 1.0625000000194,
        "Timestamp": "2019-03-29T08:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333329453,
        "Maximum": 3.23958333329453,
        "Timestamp": "2019-03-28T17:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.85416666660846,
        "Maximum": 2.85416666660846,
        "Timestamp": "2019-03-28T22:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.947916666627862,
        "Maximum": 0.947916666627862,
        "Timestamp": "2019-03-29T08:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T12:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.58196721313384,
        "Maximum": 2.58196721313384,
        "Timestamp": "2019-03-29T13:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.35416666658906,
        "Maximum": 3.35416666658906,
        "Timestamp": "2019-03-28T18:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T03:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.2500000000194,
        "Maximum": 3.2500000000194,
        "Timestamp": "2019-03-28T23:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T04:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.1874999999612,
        "Maximum": 3.1874999999612,
        "Timestamp": "2019-03-29T00:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666662786,
        "Maximum": 3.29166666662786,
        "Timestamp": "2019-03-29T16:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.67708333339154,
        "Maximum": 1.67708333339154,
        "Timestamp": "2019-03-29T12:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333335274,
        "Maximum": 2.67708333335274,
        "Timestamp": "2019-03-28T22:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.4687499999806,
        "Maximum": 3.4687499999806,
        "Timestamp": "2019-03-29T02:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52083333331393,
        "Maximum": 3.52083333331393,
        "Timestamp": "2019-03-29T02:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.30208333335274,
        "Maximum": 3.30208333335274,
        "Timestamp": "2019-03-29T17:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.80208333337214,
        "Maximum": 2.80208333337214,
        "Timestamp": "2019-03-29T13:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666668607,
        "Maximum": 2.57291666668607,
        "Timestamp": "2019-03-29T14:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.75,
        "Maximum": 3.75,
        "Timestamp": "2019-03-28T23:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.11458333335274,
        "Maximum": 1.11458333335274,
        "Timestamp": "2019-03-29T08:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.40625,
        "Maximum": 1.40625,
        "Timestamp": "2019-03-29T11:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.41188524588256,
        "Maximum": 3.41188524588256,
        "Timestamp": "2019-03-28T23:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.999999999961195,
        "Maximum": 0.999999999961195,
        "Timestamp": "2019-03-29T08:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.02083333333333,
        "Maximum": 3.02083333333333,
        "Timestamp": "2019-03-28T21:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.29166666672487,
        "Maximum": 3.29166666672487,
        "Timestamp": "2019-03-28T18:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73958333331393,
        "Maximum": 2.73958333331393,
        "Timestamp": "2019-03-29T03:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T22:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.23958333339154,
        "Maximum": 3.23958333339154,
        "Timestamp": "2019-03-28T18:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.57291666668607,
        "Maximum": 2.57291666668607,
        "Timestamp": "2019-03-29T04:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.6874999999806,
        "Maximum": 2.6874999999806,
        "Timestamp": "2019-03-29T14:44:00+00:00",
        "Unit": "Percent"
      }
    ],
    "Label": "CPUUtilization",
    "MetricDescriptor": {
      "MetricLabel": "xxxxxx max CPU %",
      "YAxis": "right",
      "Color": [
        0.84,
        0.15,
        0.166
      ],
      "MetricName": "CPUUtilization",
      "Namespace": "AWS/RDS",
      "Dimensions": [
        {
          "Name": "DBInstanceIdentifier",
          "Value": "xxxxxxxxxxxxxxxxxxx"
        }
      ],
      "Statistics": [
        "Average",
        "Maximum"
      ],
      "Unit": "Percent"
    }
  },
  {
    "Datapoints": [
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T23:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T00:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T17:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T21:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T05:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T12:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T16:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T19:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T20:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T21:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T22:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T00:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T01:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.55508474576271,
        "Maximum": 4.55508474576271,
        "Timestamp": "2019-03-29T01:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T02:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333379899,
        "Maximum": 1.33333333379899,
        "Timestamp": "2019-03-29T09:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T07:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T09:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T21:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.885416666666667,
        "Maximum": 0.885416666666667,
        "Timestamp": "2019-03-29T09:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T16:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T14:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-28T21:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T09:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T23:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T07:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T00:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T06:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T10:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T09:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T22:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T16:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T21:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T06:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T07:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T11:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T16:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.96516393473158,
        "Maximum": 3.96516393473158,
        "Timestamp": "2019-03-28T23:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T00:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T07:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T19:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T20:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T00:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T01:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T08:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T14:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T20:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-28T21:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T01:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T07:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T02:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T08:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T09:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T15:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-29T15:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T22:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T09:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T22:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T17:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.20286885245902,
        "Maximum": 2.20286885245902,
        "Timestamp": "2019-03-29T05:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.76229508150919,
        "Maximum": 1.76229508150919,
        "Timestamp": "2019-03-29T05:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T10:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T00:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T22:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T00:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T21:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T22:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T05:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T06:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T07:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.885416666666667,
        "Maximum": 0.885416666666667,
        "Timestamp": "2019-03-29T08:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T09:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T03:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T04:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T16:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T20:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T22:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.08898305021605,
        "Maximum": 4.08898305021605,
        "Timestamp": "2019-03-29T00:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333379899,
        "Maximum": 4.92708333379899,
        "Timestamp": "2019-03-28T19:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T21:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T17:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T12:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T17:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T13:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333379899,
        "Maximum": 4.92708333379899,
        "Timestamp": "2019-03-29T16:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T10:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T12:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T09:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T07:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T15:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T08:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T04:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T00:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T01:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T21:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T09:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T03:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T05:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T17:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T22:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T23:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T23:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T16:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T19:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T22:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T19:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.64406779645232,
        "Maximum": 3.64406779645232,
        "Timestamp": "2019-03-28T23:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T20:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T21:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T00:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T07:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T11:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T07:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T14:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T15:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T11:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T21:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.81144067812395,
        "Maximum": 1.81144067812395,
        "Timestamp": "2019-03-29T10:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T08:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T09:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T07:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T08:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T17:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.55508474576271,
        "Maximum": 4.55508474576271,
        "Timestamp": "2019-03-29T16:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T15:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T23:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T00:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T20:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T21:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T22:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.885416666666667,
        "Maximum": 0.885416666666667,
        "Timestamp": "2019-03-29T08:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.911016948521137,
        "Maximum": 0.911016948521137,
        "Timestamp": "2019-03-29T10:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666728755,
        "Maximum": 2.22916666728755,
        "Timestamp": "2019-03-29T06:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T07:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T09:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T23:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T21:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T15:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.911016948521137,
        "Maximum": 0.911016948521137,
        "Timestamp": "2019-03-29T08:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T17:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T23:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T16:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T22:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T08:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T01:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T10:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T01:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T07:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T22:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T16:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T15:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T21:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T10:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.32172131208611,
        "Maximum": 1.32172131208611,
        "Timestamp": "2019-03-29T08:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T16:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T20:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T21:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T00:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T01:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T06:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T22:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T16:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T08:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T17:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T21:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T21:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T00:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T14:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T15:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T16:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T19:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T21:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T22:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-28T23:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T00:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T01:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46875000062088,
        "Maximum": 4.46875000062088,
        "Timestamp": "2019-03-29T02:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T05:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T11:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.76229508150919,
        "Maximum": 1.76229508150919,
        "Timestamp": "2019-03-29T07:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T08:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T16:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T14:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.0840163935953,
        "Maximum": 3.0840163935953,
        "Timestamp": "2019-03-29T15:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T17:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T20:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T21:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T05:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333379899,
        "Maximum": 1.33333333379899,
        "Timestamp": "2019-03-29T07:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T09:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T22:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78124999937912,
        "Maximum": 1.78124999937912,
        "Timestamp": "2019-03-29T10:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T11:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T16:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.64406779645232,
        "Maximum": 3.64406779645232,
        "Timestamp": "2019-03-29T15:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T06:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T17:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46875000062088,
        "Maximum": 4.46875000062088,
        "Timestamp": "2019-03-29T16:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T17:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T23:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T00:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T21:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T09:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.82203389783153,
        "Maximum": 1.82203389783153,
        "Timestamp": "2019-03-29T10:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.96516393473158,
        "Maximum": 3.96516393473158,
        "Timestamp": "2019-03-29T00:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T01:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T16:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T15:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52459016378175,
        "Maximum": 3.52459016378175,
        "Timestamp": "2019-03-28T21:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T10:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T06:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T16:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-28T20:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T00:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T20:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T17:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T05:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78124999937912,
        "Maximum": 1.78124999937912,
        "Timestamp": "2019-03-29T06:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T01:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T21:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T09:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T22:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T15:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T07:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.911016949310394,
        "Maximum": 0.911016949310394,
        "Timestamp": "2019-03-29T11:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T18:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46875000062088,
        "Maximum": 4.46875000062088,
        "Timestamp": "2019-03-29T02:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.36652542357096,
        "Maximum": 1.36652542357096,
        "Timestamp": "2019-03-29T07:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T00:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.885416666666667,
        "Maximum": 0.885416666666667,
        "Timestamp": "2019-03-29T08:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T01:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T15:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T04:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T00:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T19:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T17:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T14:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T00:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T22:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T21:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T11:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T13:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T12:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T02:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T16:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T17:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T22:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T00:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T04:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T16:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T19:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T21:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T10:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T00:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T12:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.51434426198973,
        "Maximum": 3.51434426198973,
        "Timestamp": "2019-03-28T20:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T21:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T20:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T15:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.76229508227256,
        "Maximum": 1.76229508227256,
        "Timestamp": "2019-03-29T10:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T04:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T01:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T19:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T07:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T01:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T22:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T12:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T05:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T16:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-28T18:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T13:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73305084793118,
        "Maximum": 2.73305084793118,
        "Timestamp": "2019-03-29T13:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.900423728813559,
        "Maximum": 0.900423728813559,
        "Timestamp": "2019-03-29T07:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T22:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T19:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T10:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T20:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T20:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T02:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T17:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T07:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T07:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T11:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T21:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T09:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T05:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T15:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T19:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46875000062088,
        "Maximum": 4.46875000062088,
        "Timestamp": "2019-03-29T00:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T21:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T23:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.32172131132273,
        "Maximum": 1.32172131132273,
        "Timestamp": "2019-03-29T07:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T03:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.20286885245902,
        "Maximum": 2.20286885245902,
        "Timestamp": "2019-03-29T04:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T15:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T17:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T12:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333379899,
        "Maximum": 1.33333333379899,
        "Timestamp": "2019-03-29T11:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T23:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T22:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T20:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T19:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52459016454513,
        "Maximum": 3.52459016454513,
        "Timestamp": "2019-03-29T00:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T01:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-29T03:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T14:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T16:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T02:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T00:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T21:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T17:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T15:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T21:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T23:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T12:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T14:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T02:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T22:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T09:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37500000015522,
        "Maximum": 5.37500000015522,
        "Timestamp": "2019-03-28T19:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T13:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T20:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T23:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T07:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T14:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333379899,
        "Maximum": 1.33333333379899,
        "Timestamp": "2019-03-29T10:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T17:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T20:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T00:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T16:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T21:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T17:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T08:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T08:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T12:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T18:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T22:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333379899,
        "Maximum": 1.33333333379899,
        "Timestamp": "2019-03-29T08:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T19:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T05:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T16:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T17:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.64406779645232,
        "Maximum": 3.64406779645232,
        "Timestamp": "2019-03-28T19:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333302289,
        "Maximum": 4.92708333302289,
        "Timestamp": "2019-03-29T16:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T02:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T14:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T03:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T00:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T22:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T13:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78124999937912,
        "Maximum": 1.78124999937912,
        "Timestamp": "2019-03-29T11:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T21:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.08898305100531,
        "Maximum": 4.08898305100531,
        "Timestamp": "2019-03-28T23:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37500000015522,
        "Maximum": 5.37500000015522,
        "Timestamp": "2019-03-28T19:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T17:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666728755,
        "Maximum": 2.22916666728755,
        "Timestamp": "2019-03-29T06:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T07:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T17:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T15:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T03:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T01:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T14:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T16:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T13:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T15:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T13:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T00:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46875000062088,
        "Maximum": 4.46875000062088,
        "Timestamp": "2019-03-29T01:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T23:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T01:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T10:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46875000062088,
        "Maximum": 4.46875000062088,
        "Timestamp": "2019-03-28T18:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.881147541136282,
        "Maximum": 0.881147541136282,
        "Timestamp": "2019-03-29T09:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T20:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T18:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T17:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46875000062088,
        "Maximum": 4.46875000062088,
        "Timestamp": "2019-03-29T01:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-29T14:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T05:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T10:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T00:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T20:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T16:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T15:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T08:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T07:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-28T18:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.51434426198973,
        "Maximum": 3.51434426198973,
        "Timestamp": "2019-03-29T01:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T03:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T16:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T19:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T02:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T05:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T20:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T05:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T21:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T04:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T07:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T04:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T07:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T22:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T17:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T23:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333286767,
        "Maximum": 2.67708333286767,
        "Timestamp": "2019-03-29T13:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T08:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-28T21:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T20:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T08:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T17:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T18:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T03:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T16:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.0840163935953,
        "Maximum": 3.0840163935953,
        "Timestamp": "2019-03-29T03:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T22:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T00:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T12:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T14:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T03:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T12:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.51434426275311,
        "Maximum": 3.51434426275311,
        "Timestamp": "2019-03-29T15:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T13:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T22:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T00:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T00:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T13:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T04:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46875000062088,
        "Maximum": 4.46875000062088,
        "Timestamp": "2019-03-28T19:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T21:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T17:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T07:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T23:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.885416666666667,
        "Maximum": 0.885416666666667,
        "Timestamp": "2019-03-29T09:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37500000015522,
        "Maximum": 5.37500000015522,
        "Timestamp": "2019-03-28T19:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.40573770491803,
        "Maximum": 4.40573770491803,
        "Timestamp": "2019-03-28T17:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T17:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T03:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T21:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T17:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T18:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T06:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T22:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T22:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T12:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T09:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T19:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T07:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T04:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T19:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T08:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T04:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T23:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.55508474576271,
        "Maximum": 4.55508474576271,
        "Timestamp": "2019-03-28T18:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T08:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T05:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T11:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-29T13:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333379899,
        "Maximum": 4.92708333379899,
        "Timestamp": "2019-03-29T02:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T04:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T22:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666728755,
        "Maximum": 2.22916666728755,
        "Timestamp": "2019-03-29T05:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T19:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T21:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T11:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333286767,
        "Maximum": 2.67708333286767,
        "Timestamp": "2019-03-29T12:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T10:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T16:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T16:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T15:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T14:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T04:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T05:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333302289,
        "Maximum": 4.92708333302289,
        "Timestamp": "2019-03-29T02:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T03:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T17:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T19:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T17:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T19:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333302289,
        "Maximum": 4.92708333302289,
        "Timestamp": "2019-03-28T18:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T00:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46875000062088,
        "Maximum": 4.46875000062088,
        "Timestamp": "2019-03-29T02:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T04:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T06:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T05:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T17:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333379899,
        "Maximum": 4.92708333379899,
        "Timestamp": "2019-03-28T19:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T14:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T12:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T13:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T19:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T20:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T02:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T03:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T13:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63347457595548,
        "Maximum": 3.63347457595548,
        "Timestamp": "2019-03-29T14:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T20:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T03:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T02:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-29T03:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T04:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T21:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T10:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T14:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T15:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.40573770491803,
        "Maximum": 4.40573770491803,
        "Timestamp": "2019-03-28T18:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T03:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.73305084793118,
        "Maximum": 2.73305084793118,
        "Timestamp": "2019-03-29T04:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T11:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T11:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.64406779645232,
        "Maximum": 3.64406779645232,
        "Timestamp": "2019-03-29T15:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T04:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T18:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666728755,
        "Maximum": 2.22916666728755,
        "Timestamp": "2019-03-29T05:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T19:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.51434426275311,
        "Maximum": 3.51434426275311,
        "Timestamp": "2019-03-28T18:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T01:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T01:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T05:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T06:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T12:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-28T18:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T13:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T19:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T02:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.32172131208611,
        "Maximum": 1.32172131208611,
        "Timestamp": "2019-03-29T07:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T12:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T18:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T19:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T19:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T20:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T17:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T11:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T12:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T13:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T19:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T18:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T17:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666728755,
        "Maximum": 2.22916666728755,
        "Timestamp": "2019-03-29T12:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T14:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T09:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T10:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T05:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T01:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T03:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T13:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T09:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T18:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T20:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T01:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T03:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T21:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-29T02:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T22:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T00:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T05:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T17:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T00:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T01:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T21:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T22:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T15:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T15:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T11:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-28T18:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T17:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T17:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T13:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T19:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T20:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T05:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T02:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T12:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T13:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T09:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.32172131208611,
        "Maximum": 1.32172131208611,
        "Timestamp": "2019-03-29T10:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.63319672085345,
        "Maximum": 2.63319672085345,
        "Timestamp": "2019-03-29T13:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T09:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T06:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63347457674474,
        "Maximum": 3.63347457674474,
        "Timestamp": "2019-03-29T03:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T14:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T10:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.51434426198973,
        "Maximum": 3.51434426198973,
        "Timestamp": "2019-03-29T14:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T03:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T04:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T20:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T17:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T21:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T00:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T04:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T01:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T21:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T18:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-28T19:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T19:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T05:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T03:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.08898305100531,
        "Maximum": 4.08898305100531,
        "Timestamp": "2019-03-28T17:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T18:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T03:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.192622950667,
        "Maximum": 2.192622950667,
        "Timestamp": "2019-03-29T13:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T13:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.09957627150214,
        "Maximum": 4.09957627150214,
        "Timestamp": "2019-03-29T01:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T03:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T11:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T12:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T11:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T20:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T18:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T18:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T20:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T05:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T17:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T03:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T13:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T01:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T03:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T03:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T15:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-29T13:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T11:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-28T18:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.08898305100531,
        "Maximum": 4.08898305100531,
        "Timestamp": "2019-03-28T19:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T13:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T03:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333286767,
        "Maximum": 2.67708333286767,
        "Timestamp": "2019-03-29T04:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T01:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T19:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T20:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T14:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T05:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T11:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T02:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T15:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.17796610169492,
        "Maximum": 3.17796610169492,
        "Timestamp": "2019-03-29T03:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T18:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T19:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T14:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T15:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T03:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T04:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T19:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T19:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T01:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T13:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T11:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T14:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T02:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.39549180388939,
        "Maximum": 4.39549180388939,
        "Timestamp": "2019-03-29T02:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T05:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T18:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T18:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666728755,
        "Maximum": 2.22916666728755,
        "Timestamp": "2019-03-29T11:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T14:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T15:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T03:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.82203389862079,
        "Maximum": 1.82203389862079,
        "Timestamp": "2019-03-29T05:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T03:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18855932219175,
        "Maximum": 3.18855932219175,
        "Timestamp": "2019-03-29T04:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T14:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T11:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T13:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.31147541029409,
        "Maximum": 1.31147541029409,
        "Timestamp": "2019-03-29T10:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T16:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T15:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T17:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-28T18:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T19:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T20:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.17796610169492,
        "Maximum": 3.17796610169492,
        "Timestamp": "2019-03-28T21:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T05:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T00:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T01:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T15:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T11:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T13:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T10:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T16:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T12:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T14:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T21:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T17:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T19:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T04:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T21:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T17:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.09957627150214,
        "Maximum": 4.09957627150214,
        "Timestamp": "2019-03-28T20:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T11:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T05:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T06:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T03:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T15:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T16:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-28T19:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T19:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T11:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T12:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T01:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.39549180312601,
        "Maximum": 4.39549180312601,
        "Timestamp": "2019-03-29T01:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.20286885245902,
        "Maximum": 2.20286885245902,
        "Timestamp": "2019-03-29T05:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T17:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T21:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T10:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T01:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T14:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-29T14:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T20:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T05:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T11:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T11:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T19:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T02:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T15:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T12:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T01:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T19:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T20:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T14:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T10:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.82203389783153,
        "Maximum": 1.82203389783153,
        "Timestamp": "2019-03-29T05:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T01:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T19:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T17:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-29T01:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T02:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T16:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T08:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T05:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T00:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T18:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-29T13:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T21:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333286767,
        "Maximum": 2.67708333286767,
        "Timestamp": "2019-03-29T04:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T11:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T12:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T21:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T19:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T21:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T16:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T02:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T03:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333286767,
        "Maximum": 2.67708333286767,
        "Timestamp": "2019-03-29T05:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T17:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.36652542357096,
        "Maximum": 1.36652542357096,
        "Timestamp": "2019-03-29T09:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333379899,
        "Maximum": 1.33333333379899,
        "Timestamp": "2019-03-29T09:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T16:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T21:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T11:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T03:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T08:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T08:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T00:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T18:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-28T18:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T05:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T15:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T19:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T14:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T01:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T00:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T06:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T16:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T10:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T22:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T02:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18855932219175,
        "Maximum": 3.18855932219175,
        "Timestamp": "2019-03-29T13:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52459016378175,
        "Maximum": 3.52459016378175,
        "Timestamp": "2019-03-29T03:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T23:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-29T04:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.18855932219175,
        "Maximum": 3.18855932219175,
        "Timestamp": "2019-03-29T14:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T19:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T15:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.32172131132273,
        "Maximum": 1.32172131132273,
        "Timestamp": "2019-03-29T11:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T01:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T15:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T21:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T12:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T16:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.52459016454513,
        "Maximum": 3.52459016454513,
        "Timestamp": "2019-03-29T14:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-28T18:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T17:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T06:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T02:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T16:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T10:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T11:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T21:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T00:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.08898305100531,
        "Maximum": 4.08898305100531,
        "Timestamp": "2019-03-28T18:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T22:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T20:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46875000062088,
        "Maximum": 4.46875000062088,
        "Timestamp": "2019-03-28T18:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T07:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T04:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T08:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-28T19:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T17:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T20:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T16:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T19:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T17:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T00:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T21:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T11:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T03:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T11:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T21:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T17:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T03:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T15:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T09:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T01:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T04:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T11:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T01:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T05:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T15:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T15:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T15:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T21:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T01:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T01:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T22:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T12:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T16:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46875000062088,
        "Maximum": 4.46875000062088,
        "Timestamp": "2019-03-29T17:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T22:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.09957627071289,
        "Maximum": 4.09957627071289,
        "Timestamp": "2019-03-29T02:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T23:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T12:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.9651639339682,
        "Maximum": 3.9651639339682,
        "Timestamp": "2019-03-28T19:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T13:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T17:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T15:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T01:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T15:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T13:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T02:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T01:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T12:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T10:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.911016948521137,
        "Maximum": 0.911016948521137,
        "Timestamp": "2019-03-29T08:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T22:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T20:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T18:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T19:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T18:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T16:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T03:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.27754237288136,
        "Maximum": 2.27754237288136,
        "Timestamp": "2019-03-29T05:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T04:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T20:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T22:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T21:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T11:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T13:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T07:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T06:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T06:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T17:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333379899,
        "Maximum": 4.92708333379899,
        "Timestamp": "2019-03-28T18:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T07:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T13:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666728755,
        "Maximum": 2.22916666728755,
        "Timestamp": "2019-03-29T11:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T23:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T21:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T03:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T09:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T19:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T00:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T22:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T20:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T10:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T15:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.911016949310394,
        "Maximum": 0.911016949310394,
        "Timestamp": "2019-03-29T07:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T13:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T01:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.96516393473158,
        "Maximum": 3.96516393473158,
        "Timestamp": "2019-03-28T23:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T02:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T18:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T16:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T14:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T02:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T08:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T00:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T03:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T18:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T19:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T15:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T15:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T01:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T01:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T10:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.95491803293956,
        "Maximum": 3.95491803293956,
        "Timestamp": "2019-03-28T19:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T20:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T02:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T16:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T11:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T21:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T22:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T17:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T19:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T09:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-28T19:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T03:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T07:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T16:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T15:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.08898305021605,
        "Maximum": 4.08898305021605,
        "Timestamp": "2019-03-29T01:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T02:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.67708333364377,
        "Maximum": 2.67708333364377,
        "Timestamp": "2019-03-29T04:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T23:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T13:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T09:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T07:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T17:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T19:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T21:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T22:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T17:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T21:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T23:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333379899,
        "Maximum": 1.33333333379899,
        "Timestamp": "2019-03-29T10:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T11:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-28T18:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T18:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T20:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.32172131208611,
        "Maximum": 1.32172131208611,
        "Timestamp": "2019-03-29T08:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T03:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T04:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T06:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T07:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T09:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T03:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T05:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T18:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T17:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T00:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333379899,
        "Maximum": 1.33333333379899,
        "Timestamp": "2019-03-29T06:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T13:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T03:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T19:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T23:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T12:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.95491803293956,
        "Maximum": 3.95491803293956,
        "Timestamp": "2019-03-29T16:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-29T04:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-28T22:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T08:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T17:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T22:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666604578,
        "Maximum": 3.13541666604578,
        "Timestamp": "2019-03-29T13:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-28T18:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-28T23:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T04:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T00:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T16:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.22916666651145,
        "Maximum": 2.22916666651145,
        "Timestamp": "2019-03-29T12:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-28T22:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T02:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T02:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T17:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T13:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.13541666682189,
        "Maximum": 3.13541666682189,
        "Timestamp": "2019-03-29T14:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-28T23:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T11:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-28T23:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T12:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T21:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-28T18:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T03:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-28T22:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37500000015522,
        "Maximum": 5.37500000015522,
        "Timestamp": "2019-03-28T18:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.07377049180328,
        "Maximum": 3.07377049180328,
        "Timestamp": "2019-03-29T04:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T14:44:00+00:00",
        "Unit": "Percent"
      }
    ],
    "Label": "CPUUtilization",
    "MetricDescriptor": {
      "MetricLabel": "xxxxxx max CPU %",
      "YAxis": "right",
      "LabelColor": [
        0.9,
        0.45,
        0.054
      ],
      "Color": [
        1.0,
        0.5,
        0.06
      ],
      "MetricName": "CPUUtilization",
      "Namespace": "AWS/RDS",
      "Dimensions": [
        {
          "Name": "DBInstanceIdentifier",
          "Value": "xxxxxxxxxxxxxxxxxxx"
        }
      ],
      "Statistics": [
        "Average",
        "Maximum"
      ],
      "Unit": "Percent"
    }
  },
  {
    "Datapoints": [
      {
        "Average": 10.2916666671323,
        "Maximum": 10.2916666671323,
        "Timestamp": "2019-03-28T22:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T23:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-29T00:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T16:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8645833334886,
        "Maximum": 13.8645833334886,
        "Timestamp": "2019-03-29T17:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T21:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T06:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T07:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T04:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T10:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666604578,
        "Maximum": 6.26041666604578,
        "Timestamp": "2019-03-29T11:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T12:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T09:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-29T16:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-28T19:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-28T20:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T21:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-28T22:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T00:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7291666666667,
        "Maximum": 10.7291666666667,
        "Timestamp": "2019-03-29T01:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7291666666667,
        "Maximum": 10.7291666666667,
        "Timestamp": "2019-03-29T01:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8645833334886,
        "Maximum": 13.8645833334886,
        "Timestamp": "2019-03-29T02:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T07:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 14.760416666201,
        "Maximum": 14.760416666201,
        "Timestamp": "2019-03-29T08:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T08:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T09:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666651145,
        "Maximum": 5.82291666651145,
        "Timestamp": "2019-03-29T07:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T09:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333364378,
        "Maximum": 6.27083333364378,
        "Timestamp": "2019-03-28T20:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T21:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T00:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T02:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T07:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T09:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6250000001552,
        "Maximum": 11.6250000001552,
        "Timestamp": "2019-03-29T16:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666663562,
        "Maximum": 10.2916666663562,
        "Timestamp": "2019-03-29T14:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.59836065558503,
        "Maximum": 6.59836065558503,
        "Timestamp": "2019-03-29T16:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T14:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T21:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T09:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-28T23:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.4446721306895,
        "Maximum": 11.4446721306895,
        "Timestamp": "2019-03-29T07:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T00:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T22:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T06:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T05:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333271245,
        "Maximum": 4.02083333271245,
        "Timestamp": "2019-03-29T10:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T09:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T22:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1874999998448,
        "Maximum": 11.1874999998448,
        "Timestamp": "2019-03-29T16:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-28T21:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T06:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T07:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T10:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T11:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T16:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T23:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T00:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T07:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T08:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-28T19:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1875000006209,
        "Maximum": 11.1875000006209,
        "Timestamp": "2019-03-28T20:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T00:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T01:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T08:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T14:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T20:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T21:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T01:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T07:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T02:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T08:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666671323,
        "Maximum": 10.2916666671323,
        "Timestamp": "2019-03-29T15:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T15:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T22:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T22:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T08:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T09:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T23:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T16:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T22:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T17:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T05:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T05:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T10:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-29T00:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T10:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T22:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T23:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T00:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T01:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T02:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.60860655737705,
        "Maximum": 6.60860655737705,
        "Timestamp": "2019-03-28T21:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T22:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916667132328,
        "Maximum": 0.447916667132328,
        "Timestamp": "2019-03-29T05:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.96516393473158,
        "Maximum": 3.96516393473158,
        "Timestamp": "2019-03-29T06:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T07:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T08:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T03:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T04:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T05:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T16:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333379899,
        "Maximum": 1.33333333379899,
        "Timestamp": "2019-03-28T18:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T20:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T22:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333379899,
        "Maximum": 4.92708333379899,
        "Timestamp": "2019-03-29T00:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T00:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T16:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-28T19:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T21:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1874999998448,
        "Maximum": 11.1874999998448,
        "Timestamp": "2019-03-28T23:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T17:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T10:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T12:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T06:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T08:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T17:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T15:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T13:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T16:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T14:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T10:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T12:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T07:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T09:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T11:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-29T12:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T07:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-29T08:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T15:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T15:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T08:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T08:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T04:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T05:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T00:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T01:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-28T21:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T22:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T06:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T09:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T03:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T05:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T10:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-29T17:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-28T22:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-28T23:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T02:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-28T23:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1874999998448,
        "Maximum": 11.1874999998448,
        "Timestamp": "2019-03-29T16:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-28T19:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333379899,
        "Maximum": 1.33333333379899,
        "Timestamp": "2019-03-28T22:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 14.3229166666667,
        "Maximum": 14.3229166666667,
        "Timestamp": "2019-03-29T16:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-28T19:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T23:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7291666666667,
        "Maximum": 10.7291666666667,
        "Timestamp": "2019-03-28T23:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8645833334886,
        "Maximum": 13.8645833334886,
        "Timestamp": "2019-03-29T14:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T20:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T21:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T10:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T00:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 14.760416666201,
        "Maximum": 14.760416666201,
        "Timestamp": "2019-03-29T07:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-29T11:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333364378,
        "Maximum": 6.27083333364378,
        "Timestamp": "2019-03-29T07:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T14:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T15:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T11:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T08:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333286767,
        "Maximum": 6.27083333286767,
        "Timestamp": "2019-03-28T20:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T21:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T10:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T10:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-28T22:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T23:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 16.1041666668219,
        "Maximum": 16.1041666668219,
        "Timestamp": "2019-03-29T08:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T09:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T05:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T06:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666651145,
        "Maximum": 5.82291666651145,
        "Timestamp": "2019-03-29T07:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T08:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T17:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T16:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T15:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T22:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T23:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T00:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T01:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T23:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.03893442653486,
        "Maximum": 7.03893442653486,
        "Timestamp": "2019-03-28T20:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-28T21:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T22:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T08:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T10:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T06:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T07:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T10:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.94791666651145,
        "Maximum": 8.94791666651145,
        "Timestamp": "2019-03-29T09:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T23:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-28T21:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.75204918048054,
        "Maximum": 1.75204918048054,
        "Timestamp": "2019-03-29T15:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.59836065558503,
        "Maximum": 6.59836065558503,
        "Timestamp": "2019-03-29T06:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T08:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T17:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T00:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666651145,
        "Maximum": 5.82291666651145,
        "Timestamp": "2019-03-28T23:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T16:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-28T22:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T08:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T20:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7291666666667,
        "Maximum": 10.7291666666667,
        "Timestamp": "2019-03-28T23:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T01:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T10:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T00:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T01:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T06:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T07:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333302289,
        "Maximum": 4.92708333302289,
        "Timestamp": "2019-03-28T22:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6354166669771,
        "Maximum": 11.6354166669771,
        "Timestamp": "2019-03-29T16:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T15:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-28T21:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T10:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T07:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T08:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-28T23:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T00:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T16:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.885416666666667,
        "Maximum": 0.885416666666667,
        "Timestamp": "2019-03-29T08:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-28T20:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-28T21:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-29T00:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T01:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333364377,
        "Maximum": 9.39583333364377,
        "Timestamp": "2019-03-29T06:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T09:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T06:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T09:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.177083333799,
        "Maximum": 11.177083333799,
        "Timestamp": "2019-03-28T22:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T01:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T22:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T15:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T16:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333364378,
        "Maximum": 6.27083333364378,
        "Timestamp": "2019-03-29T07:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-29T10:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T17:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-28T23:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T21:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T23:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.94791666651145,
        "Maximum": 8.94791666651145,
        "Timestamp": "2019-03-29T08:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T09:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-28T21:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T00:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666651145,
        "Maximum": 5.82291666651145,
        "Timestamp": "2019-03-29T06:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T14:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-29T15:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-29T16:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T19:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T20:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-28T21:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T22:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T23:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T00:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T01:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T02:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T05:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T10:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T11:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T06:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T07:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.2881355932203,
        "Maximum": 12.2881355932203,
        "Timestamp": "2019-03-29T08:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666728755,
        "Maximum": 5.82291666728755,
        "Timestamp": "2019-03-29T08:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T09:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.32172131132273,
        "Maximum": 1.32172131132273,
        "Timestamp": "2019-03-29T16:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T14:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-29T15:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T17:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81250000046566,
        "Maximum": 5.81250000046566,
        "Timestamp": "2019-03-29T15:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T23:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T01:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T20:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-28T21:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.885416666666667,
        "Maximum": 0.885416666666667,
        "Timestamp": "2019-03-29T05:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T07:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-29T09:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T00:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T02:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-28T20:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T22:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T10:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T09:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2812499995343,
        "Maximum": 10.2812499995343,
        "Timestamp": "2019-03-29T11:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666660458,
        "Maximum": 12.9791666660458,
        "Timestamp": "2019-03-29T16:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T15:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T06:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T07:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 14.099576270555,
        "Maximum": 14.099576270555,
        "Timestamp": "2019-03-29T17:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T16:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.61458333348855,
        "Maximum": 7.61458333348855,
        "Timestamp": "2019-03-29T17:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T23:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-29T00:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T20:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-28T21:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333286767,
        "Maximum": 9.39583333286767,
        "Timestamp": "2019-03-29T06:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T09:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T10:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T22:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.7561475409836,
        "Maximum": 12.7561475409836,
        "Timestamp": "2019-03-29T00:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.7436440674809,
        "Maximum": 12.7436440674809,
        "Timestamp": "2019-03-29T01:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T05:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T16:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T15:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T21:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T10:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T11:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T06:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T07:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-29T16:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T11:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T07:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-28T23:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7291666666667,
        "Maximum": 10.7291666666667,
        "Timestamp": "2019-03-28T20:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T00:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T20:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T09:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T17:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T05:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T06:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T01:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T21:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.83262711864407,
        "Maximum": 6.83262711864407,
        "Timestamp": "2019-03-29T09:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T01:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T22:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T10:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-29T15:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-29T15:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T07:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T07:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T11:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-28T18:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333379899,
        "Maximum": 1.33333333379899,
        "Timestamp": "2019-03-29T02:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T07:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T00:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333286767,
        "Maximum": 6.27083333286767,
        "Timestamp": "2019-03-29T08:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.03893442653486,
        "Maximum": 7.03893442653486,
        "Timestamp": "2019-03-29T01:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-29T15:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T14:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T09:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T12:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.010593220339,
        "Maximum": 10.010593220339,
        "Timestamp": "2019-03-29T04:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T06:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T00:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T19:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T17:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T14:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37500000015522,
        "Maximum": 5.37500000015522,
        "Timestamp": "2019-03-29T00:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37499999937912,
        "Maximum": 5.37499999937912,
        "Timestamp": "2019-03-28T22:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T21:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T23:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T11:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T13:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T12:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T02:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T04:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T16:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T14:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T17:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T22:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T00:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666660458,
        "Maximum": 12.9791666660458,
        "Timestamp": "2019-03-29T03:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T04:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T16:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.125,
        "Maximum": 3.125,
        "Timestamp": "2019-03-28T19:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T21:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T09:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T11:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T02:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T10:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T00:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T14:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T12:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666663562,
        "Maximum": 10.2916666663562,
        "Timestamp": "2019-03-29T15:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-29T16:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T20:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-28T21:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-28T20:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-29T15:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T10:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333286767,
        "Maximum": 6.27083333286767,
        "Timestamp": "2019-03-29T04:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T15:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T01:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T09:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-28T19:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6354166669771,
        "Maximum": 11.6354166669771,
        "Timestamp": "2019-03-29T07:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666671323,
        "Maximum": 10.2916666671323,
        "Timestamp": "2019-03-29T01:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-28T22:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-29T12:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-29T16:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916667132328,
        "Maximum": 0.447916667132328,
        "Timestamp": "2019-03-29T08:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-28T18:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T13:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T02:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.76229508227256,
        "Maximum": 1.76229508227256,
        "Timestamp": "2019-03-29T13:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T23:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.635416666201,
        "Maximum": 11.635416666201,
        "Timestamp": "2019-03-29T07:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T09:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666604578,
        "Maximum": 6.26041666604578,
        "Timestamp": "2019-03-29T05:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T22:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666604578,
        "Maximum": 6.26041666604578,
        "Timestamp": "2019-03-29T05:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T19:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-28T23:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T10:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T11:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T06:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.61458333348855,
        "Maximum": 7.61458333348855,
        "Timestamp": "2019-03-28T20:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T20:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T02:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8645833334886,
        "Maximum": 13.8645833334886,
        "Timestamp": "2019-03-29T17:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T07:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T07:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T11:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T21:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-29T03:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1770833330229,
        "Maximum": 11.1770833330229,
        "Timestamp": "2019-03-29T04:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333286767,
        "Maximum": 6.27083333286767,
        "Timestamp": "2019-03-29T08:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T08:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.1967213119334,
        "Maximum": 13.1967213119334,
        "Timestamp": "2019-03-28T18:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T09:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T11:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T03:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T05:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T07:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.61458333348855,
        "Maximum": 7.61458333348855,
        "Timestamp": "2019-03-29T15:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-29T15:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T13:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-28T19:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-29T01:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T00:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-28T21:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833339542,
        "Maximum": 13.4270833339542,
        "Timestamp": "2019-03-28T23:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T07:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T01:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333302289,
        "Maximum": 4.92708333302289,
        "Timestamp": "2019-03-29T03:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T04:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T15:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T17:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.1885593220339,
        "Maximum": 13.1885593220339,
        "Timestamp": "2019-03-29T12:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T09:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333286767,
        "Maximum": 9.39583333286767,
        "Timestamp": "2019-03-29T11:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T13:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.885416666666667,
        "Maximum": 0.885416666666667,
        "Timestamp": "2019-03-28T23:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-28T22:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-28T20:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T19:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T00:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T01:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666671323,
        "Maximum": 10.2916666671323,
        "Timestamp": "2019-03-29T03:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T14:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T16:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T02:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T23:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1770833330229,
        "Maximum": 11.1770833330229,
        "Timestamp": "2019-03-29T00:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6249999993791,
        "Maximum": 11.6249999993791,
        "Timestamp": "2019-03-29T11:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T13:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T12:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T13:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-28T21:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T17:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.82203389862079,
        "Maximum": 1.82203389862079,
        "Timestamp": "2019-03-29T15:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666660458,
        "Maximum": 12.9791666660458,
        "Timestamp": "2019-03-29T03:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T21:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-28T23:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T01:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T12:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T14:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T02:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-28T22:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T09:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T06:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 14.3229166666667,
        "Maximum": 14.3229166666667,
        "Timestamp": "2019-03-28T19:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.177083333799,
        "Maximum": 11.177083333799,
        "Timestamp": "2019-03-29T13:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T20:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T23:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T07:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T10:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T04:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T14:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T10:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T17:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-28T20:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T00:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.455508474260569,
        "Maximum": 0.455508474260569,
        "Timestamp": "2019-03-29T06:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T04:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T16:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T11:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-28T21:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-28T17:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6354166669771,
        "Maximum": 11.6354166669771,
        "Timestamp": "2019-03-29T08:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T08:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-29T08:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666604578,
        "Maximum": 6.26041666604578,
        "Timestamp": "2019-03-29T12:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T18:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-28T22:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T04:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-28T18:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T05:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6354166669771,
        "Maximum": 11.6354166669771,
        "Timestamp": "2019-03-29T08:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6250000001552,
        "Maximum": 11.6250000001552,
        "Timestamp": "2019-03-29T09:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81250000046566,
        "Maximum": 5.81250000046566,
        "Timestamp": "2019-03-28T18:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T19:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T05:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T06:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T05:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-29T16:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T10:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T17:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-28T19:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7291666666667,
        "Maximum": 10.7291666666667,
        "Timestamp": "2019-03-29T02:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-29T16:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T03:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333286767,
        "Maximum": 6.27083333286767,
        "Timestamp": "2019-03-29T05:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T02:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T14:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 18.3437500001552,
        "Maximum": 18.3437500001552,
        "Timestamp": "2019-03-29T03:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T00:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T22:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T13:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T13:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T11:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333364377,
        "Maximum": 9.39583333364377,
        "Timestamp": "2019-03-29T09:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T11:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-28T21:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666660458,
        "Maximum": 12.9791666660458,
        "Timestamp": "2019-03-28T23:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T19:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-28T20:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.7561475409836,
        "Maximum": 12.7561475409836,
        "Timestamp": "2019-03-28T17:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T06:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916667132328,
        "Maximum": 0.447916667132328,
        "Timestamp": "2019-03-29T07:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T17:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.06249999984478,
        "Maximum": 8.06249999984478,
        "Timestamp": "2019-03-29T15:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T06:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T04:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-29T03:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T01:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T18:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T14:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T16:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T13:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T15:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333379899,
        "Maximum": 4.92708333379899,
        "Timestamp": "2019-03-29T13:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T23:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T00:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T01:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T03:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T23:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T01:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T08:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T10:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6250000001552,
        "Maximum": 11.6250000001552,
        "Timestamp": "2019-03-28T20:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-28T18:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T09:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T10:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T20:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T18:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T03:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.7663934427756,
        "Maximum": 12.7663934427756,
        "Timestamp": "2019-03-29T17:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T15:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T01:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666671323,
        "Maximum": 10.2916666671323,
        "Timestamp": "2019-03-29T08:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T14:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T05:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T10:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T18:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T00:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833327124,
        "Maximum": 10.7395833327124,
        "Timestamp": "2019-03-28T20:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T02:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T16:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8645833334886,
        "Maximum": 13.8645833334886,
        "Timestamp": "2019-03-29T15:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T08:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T07:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37500000015522,
        "Maximum": 5.37500000015522,
        "Timestamp": "2019-03-29T12:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T18:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.03893442653486,
        "Maximum": 7.03893442653486,
        "Timestamp": "2019-03-29T01:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T22:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T03:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T09:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T16:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T14:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T19:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T02:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T08:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T05:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T20:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-28T20:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T11:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333364377,
        "Maximum": 9.39583333364377,
        "Timestamp": "2019-03-29T11:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.885416666666667,
        "Maximum": 0.885416666666667,
        "Timestamp": "2019-03-29T05:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T06:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-28T21:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-28T22:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T12:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T12:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 16.9999999995343,
        "Maximum": 16.9999999995343,
        "Timestamp": "2019-03-29T04:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.94791666651145,
        "Maximum": 8.94791666651145,
        "Timestamp": "2019-03-29T07:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T04:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T07:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-28T22:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T17:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-28T23:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T23:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T13:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T08:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T10:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T12:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T21:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-28T20:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.82203389862079,
        "Maximum": 1.82203389862079,
        "Timestamp": "2019-03-28T18:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T08:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T17:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37500000015522,
        "Maximum": 5.37500000015522,
        "Timestamp": "2019-03-28T18:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T04:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T06:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T03:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T16:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.18855932171819,
        "Maximum": 8.18855932171819,
        "Timestamp": "2019-03-29T14:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.6372950821199,
        "Maximum": 13.6372950821199,
        "Timestamp": "2019-03-29T01:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T03:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-28T22:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.4446721314529,
        "Maximum": 11.4446721314529,
        "Timestamp": "2019-03-29T00:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333286767,
        "Maximum": 6.27083333286767,
        "Timestamp": "2019-03-29T12:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T10:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T12:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333364378,
        "Maximum": 6.27083333364378,
        "Timestamp": "2019-03-29T08:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T14:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T03:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-29T16:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T14:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.82203389814723,
        "Maximum": 6.82203389814723,
        "Timestamp": "2019-03-29T12:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T15:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T16:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T13:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-28T22:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T00:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T02:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-28T23:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81250000046566,
        "Maximum": 5.81250000046566,
        "Timestamp": "2019-03-29T00:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T13:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81250000046566,
        "Maximum": 5.81250000046566,
        "Timestamp": "2019-03-29T09:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333364378,
        "Maximum": 6.27083333364378,
        "Timestamp": "2019-03-29T11:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37500000015522,
        "Maximum": 5.37500000015522,
        "Timestamp": "2019-03-29T02:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T04:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.49999999937912,
        "Maximum": 8.49999999937912,
        "Timestamp": "2019-03-28T19:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T21:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T23:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T17:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T07:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-28T23:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T04:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T12:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T09:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333364377,
        "Maximum": 9.39583333364377,
        "Timestamp": "2019-03-29T07:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T22:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T19:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-28T17:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-29T17:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-29T13:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666663562,
        "Maximum": 10.2916666663562,
        "Timestamp": "2019-03-29T03:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333302289,
        "Maximum": 4.92708333302289,
        "Timestamp": "2019-03-28T23:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T08:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8645833334886,
        "Maximum": 13.8645833334886,
        "Timestamp": "2019-03-28T18:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T21:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666728755,
        "Maximum": 5.82291666728755,
        "Timestamp": "2019-03-29T11:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-29T14:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 22.3645833336438,
        "Maximum": 22.3645833336438,
        "Timestamp": "2019-03-29T08:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T17:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333364378,
        "Maximum": 6.27083333364378,
        "Timestamp": "2019-03-29T04:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T00:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.635416666201,
        "Maximum": 11.635416666201,
        "Timestamp": "2019-03-28T18:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666651145,
        "Maximum": 5.82291666651145,
        "Timestamp": "2019-03-29T06:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T03:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-28T22:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T22:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.27754237319706,
        "Maximum": 7.27754237319706,
        "Timestamp": "2019-03-29T12:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T09:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T19:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.885416666666667,
        "Maximum": 0.885416666666667,
        "Timestamp": "2019-03-29T07:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.06249999984478,
        "Maximum": 8.06249999984478,
        "Timestamp": "2019-03-29T04:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1874999998448,
        "Maximum": 11.1874999998448,
        "Timestamp": "2019-03-29T13:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T19:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T08:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T04:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.35593220386338,
        "Maximum": 1.35593220386338,
        "Timestamp": "2019-03-28T23:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T18:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-28T18:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T08:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T05:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T11:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T12:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-29T13:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T14:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T02:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T03:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-29T04:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T22:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T05:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-28T19:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T20:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T21:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T11:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T12:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T09:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T10:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T16:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T16:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8750000003104,
        "Maximum": 13.8750000003104,
        "Timestamp": "2019-03-29T15:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T14:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T04:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T05:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T02:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T03:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-28T17:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T18:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T19:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.82203389862079,
        "Maximum": 1.82203389862079,
        "Timestamp": "2019-03-29T16:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T14:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6354166669771,
        "Maximum": 11.6354166669771,
        "Timestamp": "2019-03-28T17:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-28T19:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T18:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T12:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T13:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T00:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-29T01:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T00:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T02:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T04:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.82203389814723,
        "Maximum": 6.82203389814723,
        "Timestamp": "2019-03-29T06:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T07:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-28T17:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68749999968956,
        "Maximum": 2.68749999968956,
        "Timestamp": "2019-03-28T19:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T12:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-29T14:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T12:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T13:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T19:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T20:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T02:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T03:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T13:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T14:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T20:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T03:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T02:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166672876,
        "Maximum": 12.0729166672876,
        "Timestamp": "2019-03-29T03:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.7663934427756,
        "Maximum": 12.7663934427756,
        "Timestamp": "2019-03-29T04:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T21:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T09:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T10:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T14:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-29T15:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T18:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-29T03:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T04:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333364378,
        "Maximum": 6.27083333364378,
        "Timestamp": "2019-03-29T11:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T11:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T11:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T15:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37499999937912,
        "Maximum": 5.37499999937912,
        "Timestamp": "2019-03-29T16:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666604578,
        "Maximum": 6.26041666604578,
        "Timestamp": "2019-03-29T00:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.28813559290464,
        "Maximum": 7.28813559290464,
        "Timestamp": "2019-03-29T04:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T18:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-28T19:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833339542,
        "Maximum": 13.4270833339542,
        "Timestamp": "2019-03-29T12:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-28T18:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T12:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T01:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-29T01:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666728755,
        "Maximum": 5.82291666728755,
        "Timestamp": "2019-03-29T05:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T06:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666663562,
        "Maximum": 10.2916666663562,
        "Timestamp": "2019-03-29T12:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-28T18:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T13:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T19:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T14:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8749999995343,
        "Maximum": 13.8749999995343,
        "Timestamp": "2019-03-29T02:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T02:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T07:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T12:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.3771186439099,
        "Maximum": 11.3771186439099,
        "Timestamp": "2019-03-28T18:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-28T19:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T19:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-28T20:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7291666666667,
        "Maximum": 10.7291666666667,
        "Timestamp": "2019-03-29T15:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T16:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T17:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666663562,
        "Maximum": 10.2916666663562,
        "Timestamp": "2019-03-29T14:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.63347457595548,
        "Maximum": 3.63347457595548,
        "Timestamp": "2019-03-29T11:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T12:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T13:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T13:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333364378,
        "Maximum": 6.27083333364378,
        "Timestamp": "2019-03-28T20:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-28T19:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.61458333348855,
        "Maximum": 7.61458333348855,
        "Timestamp": "2019-03-28T18:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-28T17:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T12:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T14:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T09:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T10:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T07:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T01:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666604578,
        "Maximum": 6.26041666604578,
        "Timestamp": "2019-03-29T03:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T04:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T06:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T07:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-29T02:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T14:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T11:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T13:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T09:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T04:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T18:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-28T20:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T01:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T03:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-28T21:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T23:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T02:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T03:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-28T22:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T00:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T05:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T05:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-28T17:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T18:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T00:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T01:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.82203389893649,
        "Maximum": 6.82203389893649,
        "Timestamp": "2019-03-29T04:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-28T21:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T22:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T15:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333302289,
        "Maximum": 4.92708333302289,
        "Timestamp": "2019-03-29T15:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916667132328,
        "Maximum": 0.447916667132328,
        "Timestamp": "2019-03-29T11:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T12:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T18:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T17:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833339542,
        "Maximum": 13.4270833339542,
        "Timestamp": "2019-03-29T16:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T17:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.3258196718258,
        "Maximum": 12.3258196718258,
        "Timestamp": "2019-03-29T12:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-29T13:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T19:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T20:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T05:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T06:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T02:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T03:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-29T12:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2812500003104,
        "Maximum": 10.2812500003104,
        "Timestamp": "2019-03-29T13:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T09:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T10:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833339542,
        "Maximum": 13.4270833339542,
        "Timestamp": "2019-03-29T13:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T09:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666604578,
        "Maximum": 6.26041666604578,
        "Timestamp": "2019-03-29T06:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T02:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T06:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T03:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T14:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T10:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T14:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T11:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T03:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T23:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666604578,
        "Maximum": 6.26041666604578,
        "Timestamp": "2019-03-29T07:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 15.2083333333333,
        "Maximum": 15.2083333333333,
        "Timestamp": "2019-03-29T04:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T20:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.92161016933367,
        "Maximum": 5.92161016933367,
        "Timestamp": "2019-03-28T17:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1770833330229,
        "Maximum": 11.1770833330229,
        "Timestamp": "2019-03-28T21:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1874999998448,
        "Maximum": 11.1874999998448,
        "Timestamp": "2019-03-29T00:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T04:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T01:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-28T21:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T04:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-28T18:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-28T19:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833327124,
        "Maximum": 10.7395833327124,
        "Timestamp": "2019-03-28T19:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-28T20:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.885416666666667,
        "Maximum": 0.885416666666667,
        "Timestamp": "2019-03-29T05:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T06:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T03:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T04:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T17:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-28T18:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T03:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.61458333271245,
        "Maximum": 7.61458333271245,
        "Timestamp": "2019-03-29T14:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-29T13:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-29T13:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.45550847457627,
        "Maximum": 5.45550847457627,
        "Timestamp": "2019-03-29T01:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T02:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T03:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T15:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T11:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T12:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T13:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T10:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T11:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T13:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T20:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-28T18:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T18:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T20:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T17:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8750000003104,
        "Maximum": 13.8750000003104,
        "Timestamp": "2019-03-28T18:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T03:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T14:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T13:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T01:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166672876,
        "Maximum": 12.0729166672876,
        "Timestamp": "2019-03-29T03:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T04:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333364378,
        "Maximum": 6.27083333364378,
        "Timestamp": "2019-03-29T06:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T02:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T03:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T10:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T12:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T15:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T13:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T11:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T13:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.76229508150919,
        "Maximum": 1.76229508150919,
        "Timestamp": "2019-03-28T18:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T19:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T12:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T13:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 15.6562499996896,
        "Maximum": 15.6562499996896,
        "Timestamp": "2019-03-29T03:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T04:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T01:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T02:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T19:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T20:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-28T18:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T13:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.59836065558503,
        "Maximum": 6.59836065558503,
        "Timestamp": "2019-03-29T14:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T11:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T06:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666651145,
        "Maximum": 5.82291666651145,
        "Timestamp": "2019-03-29T05:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T11:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T02:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T15:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T03:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-28T18:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T19:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T14:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8645833334886,
        "Maximum": 13.8645833334886,
        "Timestamp": "2019-03-29T15:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T03:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-29T12:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-29T04:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.47916666666667,
        "Maximum": 4.47916666666667,
        "Timestamp": "2019-03-29T12:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-28T19:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-28T19:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T01:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-29T04:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-29T13:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666651145,
        "Maximum": 5.82291666651145,
        "Timestamp": "2019-03-29T11:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T14:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-28T20:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T02:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81250000046566,
        "Maximum": 5.81250000046566,
        "Timestamp": "2019-03-29T05:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T02:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T05:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T18:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-28T18:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37500000015522,
        "Maximum": 5.37500000015522,
        "Timestamp": "2019-03-29T11:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.50000000015522,
        "Maximum": 8.50000000015522,
        "Timestamp": "2019-03-29T14:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T12:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T15:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.36652542357096,
        "Maximum": 1.36652542357096,
        "Timestamp": "2019-03-29T03:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T05:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T05:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T06:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T01:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T02:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T03:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-29T04:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T00:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T14:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T10:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T11:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T12:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T13:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T10:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T16:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T15:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T17:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666671323,
        "Maximum": 10.2916666671323,
        "Timestamp": "2019-03-28T18:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-28T19:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.1577868846352,
        "Maximum": 6.1577868846352,
        "Timestamp": "2019-03-28T20:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6354166669771,
        "Maximum": 11.6354166669771,
        "Timestamp": "2019-03-28T21:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T04:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-29T05:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T06:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T06:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T00:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T02:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T01:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T03:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T15:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666635623,
        "Maximum": 3.57291666635623,
        "Timestamp": "2019-03-29T11:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T13:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.36652542357096,
        "Maximum": 1.36652542357096,
        "Timestamp": "2019-03-29T04:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T06:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916667132328,
        "Maximum": 0.447916667132328,
        "Timestamp": "2019-03-29T10:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T10:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T16:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.03893442653486,
        "Maximum": 7.03893442653486,
        "Timestamp": "2019-03-29T12:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T14:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T20:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T18:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-28T21:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T17:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-28T19:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.96516393473158,
        "Maximum": 3.96516393473158,
        "Timestamp": "2019-03-29T06:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666620101,
        "Maximum": 1.79166666620101,
        "Timestamp": "2019-03-29T00:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T02:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T04:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T21:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T17:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-28T20:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T14:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.94791666728755,
        "Maximum": 8.94791666728755,
        "Timestamp": "2019-03-29T11:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T13:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333364377,
        "Maximum": 9.39583333364377,
        "Timestamp": "2019-03-29T10:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T05:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T06:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6250000001552,
        "Maximum": 11.6250000001552,
        "Timestamp": "2019-03-29T02:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T03:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.47950819672131,
        "Maximum": 7.47950819672131,
        "Timestamp": "2019-03-29T15:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T16:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-28T19:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-28T19:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T11:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T12:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666660458,
        "Maximum": 12.9791666660458,
        "Timestamp": "2019-03-29T01:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.7436440682702,
        "Maximum": 12.7436440682702,
        "Timestamp": "2019-03-29T01:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T04:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.6546610167913,
        "Maximum": 13.6546610167913,
        "Timestamp": "2019-03-28T17:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T20:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-28T21:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T10:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T01:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T14:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T02:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-29T14:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T20:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03125000031044,
        "Maximum": 4.03125000031044,
        "Timestamp": "2019-03-29T05:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.03124999953434,
        "Maximum": 4.03124999953434,
        "Timestamp": "2019-03-29T06:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T11:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T11:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T19:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T02:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T15:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T15:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T12:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T01:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T04:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T19:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T20:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T14:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T10:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T05:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-29T01:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T19:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-28T17:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T00:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T01:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T07:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T02:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T15:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81250000046566,
        "Maximum": 5.81250000046566,
        "Timestamp": "2019-03-29T16:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T08:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333364377,
        "Maximum": 9.39583333364377,
        "Timestamp": "2019-03-29T07:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T11:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T05:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T00:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T18:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T13:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-28T21:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T23:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T14:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.881147541136282,
        "Maximum": 0.881147541136282,
        "Timestamp": "2019-03-29T04:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T06:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T07:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T09:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T11:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T10:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T12:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T21:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833332712451,
        "Maximum": 0.895833332712451,
        "Timestamp": "2019-03-29T05:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.50000000015522,
        "Maximum": 8.50000000015522,
        "Timestamp": "2019-03-28T19:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T21:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-28T20:06:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.1885593220339,
        "Maximum": 13.1885593220339,
        "Timestamp": "2019-03-29T16:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T02:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T04:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-29T03:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T05:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T17:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333364378,
        "Maximum": 6.27083333364378,
        "Timestamp": "2019-03-29T07:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T09:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333286767,
        "Maximum": 6.27083333286767,
        "Timestamp": "2019-03-29T07:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T09:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T18:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8750000003104,
        "Maximum": 13.8750000003104,
        "Timestamp": "2019-03-29T16:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833339542,
        "Maximum": 13.4270833339542,
        "Timestamp": "2019-03-28T21:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T11:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8750000003104,
        "Maximum": 13.8750000003104,
        "Timestamp": "2019-03-29T03:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T02:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-29T14:29:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T08:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T08:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666663562,
        "Maximum": 10.2916666663562,
        "Timestamp": "2019-03-29T00:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-28T18:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666663562,
        "Maximum": 10.2916666663562,
        "Timestamp": "2019-03-29T13:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T18:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T22:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-29T05:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T15:43:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T09:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833339542,
        "Maximum": 13.4270833339542,
        "Timestamp": "2019-03-28T19:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-29T14:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T01:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T12:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.82203389814723,
        "Maximum": 6.82203389814723,
        "Timestamp": "2019-03-29T00:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166672876,
        "Maximum": 12.0729166672876,
        "Timestamp": "2019-03-29T06:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T16:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T10:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333364378,
        "Maximum": 6.27083333364378,
        "Timestamp": "2019-03-29T06:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-28T22:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-28T22:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.03893442577148,
        "Maximum": 7.03893442577148,
        "Timestamp": "2019-03-29T12:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1874999998448,
        "Maximum": 11.1874999998448,
        "Timestamp": "2019-03-29T02:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-29T13:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666671323,
        "Maximum": 13.4166666671323,
        "Timestamp": "2019-03-29T03:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T14:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.76229508150919,
        "Maximum": 1.76229508150919,
        "Timestamp": "2019-03-28T23:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.59836065558503,
        "Maximum": 6.59836065558503,
        "Timestamp": "2019-03-29T09:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-28T23:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-29T04:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T04:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T14:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T19:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T15:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-28T20:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333286767,
        "Maximum": 9.39583333286767,
        "Timestamp": "2019-03-29T10:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T00:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T11:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T01:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-29T15:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-28T21:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1874999998448,
        "Maximum": 11.1874999998448,
        "Timestamp": "2019-03-29T08:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T08:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T10:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T12:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T04:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T06:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-29T16:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333302289,
        "Maximum": 4.92708333302289,
        "Timestamp": "2019-03-29T14:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8749999995343,
        "Maximum": 13.8749999995343,
        "Timestamp": "2019-03-28T18:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-28T17:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T00:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T02:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-28T22:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-28T20:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666651145,
        "Maximum": 5.82291666651145,
        "Timestamp": "2019-03-29T05:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T06:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T08:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34375000062088,
        "Maximum": 1.34375000062088,
        "Timestamp": "2019-03-29T02:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T03:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T16:20:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-29T14:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T10:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333286767,
        "Maximum": 9.39583333286767,
        "Timestamp": "2019-03-29T11:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T21:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.33333333302289,
        "Maximum": 1.33333333302289,
        "Timestamp": "2019-03-29T00:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-28T18:15:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T20:01:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.92708333379899,
        "Maximum": 4.92708333379899,
        "Timestamp": "2019-03-28T22:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.45550847457627,
        "Maximum": 5.45550847457627,
        "Timestamp": "2019-03-28T20:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.82291666651145,
        "Maximum": 5.82291666651145,
        "Timestamp": "2019-03-28T18:52:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.94791666651145,
        "Maximum": 8.94791666651145,
        "Timestamp": "2019-03-29T07:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T04:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.83333333317811,
        "Maximum": 9.83333333317811,
        "Timestamp": "2019-03-29T06:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T07:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T09:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T08:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T10:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333395422,
        "Maximum": 3.58333333395422,
        "Timestamp": "2019-03-28T19:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.61458333348855,
        "Maximum": 7.61458333348855,
        "Timestamp": "2019-03-28T17:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T20:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-28T18:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T04:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37500000015522,
        "Maximum": 5.37500000015522,
        "Timestamp": "2019-03-29T06:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T16:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T02:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-28T19:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T23:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T10:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T17:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T14:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.79166666697711,
        "Maximum": 1.79166666697711,
        "Timestamp": "2019-03-29T00:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T21:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.04918032832688,
        "Maximum": 7.04918032832688,
        "Timestamp": "2019-03-29T11:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T03:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T06:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T13:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T11:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666713233,
        "Maximum": 7.16666666713233,
        "Timestamp": "2019-03-28T23:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.1885593220339,
        "Maximum": 13.1885593220339,
        "Timestamp": "2019-03-28T21:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-28T17:38:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.58333333317811,
        "Maximum": 3.58333333317811,
        "Timestamp": "2019-03-29T07:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T03:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 14.3124999998448,
        "Maximum": 14.3124999998448,
        "Timestamp": "2019-03-29T15:11:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.635416666201,
        "Maximum": 11.635416666201,
        "Timestamp": "2019-03-29T09:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T12:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.61458333348855,
        "Maximum": 7.61458333348855,
        "Timestamp": "2019-03-29T01:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.59836065558503,
        "Maximum": 6.59836065558503,
        "Timestamp": "2019-03-29T04:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T11:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T01:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T05:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T15:48:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8749999995343,
        "Maximum": 13.8749999995343,
        "Timestamp": "2019-03-29T15:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T15:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T21:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-29T01:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1770833330229,
        "Maximum": 11.1770833330229,
        "Timestamp": "2019-03-29T01:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T22:10:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-29T12:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T12:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T16:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-29T17:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T02:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-28T22:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T02:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.1874999998448,
        "Maximum": 11.1874999998448,
        "Timestamp": "2019-03-29T09:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T23:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.68750000046566,
        "Maximum": 2.68750000046566,
        "Timestamp": "2019-03-29T13:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T12:57:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333364377,
        "Maximum": 9.39583333364377,
        "Timestamp": "2019-03-28T19:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78124999937912,
        "Maximum": 1.78124999937912,
        "Timestamp": "2019-03-29T13:34:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833327124,
        "Maximum": 10.7395833327124,
        "Timestamp": "2019-03-28T22:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T17:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T15:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.32172131132273,
        "Maximum": 1.32172131132273,
        "Timestamp": "2019-03-29T04:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.911016948521137,
        "Maximum": 0.911016948521137,
        "Timestamp": "2019-03-29T06:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T01:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T15:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 14.3229166666667,
        "Maximum": 14.3229166666667,
        "Timestamp": "2019-03-29T13:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T02:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T01:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-28T23:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T12:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T10:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333364377,
        "Maximum": 9.39583333364377,
        "Timestamp": "2019-03-29T10:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333364377,
        "Maximum": 9.39583333364377,
        "Timestamp": "2019-03-29T08:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-28T22:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-28T20:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T18:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-28T19:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T08:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8645833327124,
        "Maximum": 13.8645833327124,
        "Timestamp": "2019-03-28T18:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T06:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T16:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T03:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T04:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T06:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.39583333286767,
        "Maximum": 9.39583333286767,
        "Timestamp": "2019-03-29T10:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T12:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T20:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T22:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T21:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T23:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T11:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-29T13:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.55508474607841,
        "Maximum": 9.55508474607841,
        "Timestamp": "2019-03-29T07:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T06:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-29T03:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T08:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T06:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T17:47:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81250000046566,
        "Maximum": 5.81250000046566,
        "Timestamp": "2019-03-28T18:24:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6250000001552,
        "Maximum": 11.6250000001552,
        "Timestamp": "2019-03-29T07:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.46874999984478,
        "Maximum": 4.46874999984478,
        "Timestamp": "2019-03-29T13:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T05:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T11:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T23:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833327124,
        "Maximum": 10.7395833327124,
        "Timestamp": "2019-03-28T21:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T03:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.02083333348855,
        "Maximum": 4.02083333348855,
        "Timestamp": "2019-03-29T09:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T14:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T06:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T13:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T19:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T00:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T22:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T04:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.74364406795446,
        "Maximum": 7.74364406795446,
        "Timestamp": "2019-03-28T20:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.27083333286767,
        "Maximum": 6.27083333286767,
        "Timestamp": "2019-03-29T10:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T15:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916667132328,
        "Maximum": 0.447916667132328,
        "Timestamp": "2019-03-29T07:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T13:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T01:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.37500000015522,
        "Maximum": 5.37500000015522,
        "Timestamp": "2019-03-28T23:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T02:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T08:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T18:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T16:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T14:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T14:39:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-28T23:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T02:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T08:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T00:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.6250000001552,
        "Maximum": 11.6250000001552,
        "Timestamp": "2019-03-29T03:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T09:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-28T18:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-28T19:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-29T15:16:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8645833327124,
        "Maximum": 13.8645833327124,
        "Timestamp": "2019-03-29T15:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T01:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 3.57291666713233,
        "Maximum": 3.57291666713233,
        "Timestamp": "2019-03-29T09:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T01:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-29T10:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-28T19:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T20:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.61458333348855,
        "Maximum": 7.61458333348855,
        "Timestamp": "2019-03-29T02:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T16:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-29T07:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T12:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312500004657,
        "Maximum": 12.5312500004657,
        "Timestamp": "2019-03-29T09:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T11:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-28T21:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T22:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-28T17:33:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-28T19:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T09:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-28T19:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T03:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T05:40:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T07:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 2.23958333333333,
        "Maximum": 2.23958333333333,
        "Timestamp": "2019-03-29T16:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.2775423724078,
        "Maximum": 7.2775423724078,
        "Timestamp": "2019-03-29T15:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.7436440682702,
        "Maximum": 12.7436440682702,
        "Timestamp": "2019-03-29T01:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T02:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-29T04:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.2916666663562,
        "Maximum": 10.2916666663562,
        "Timestamp": "2019-03-28T23:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T13:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T09:35:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T11:21:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T07:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.2775423724078,
        "Maximum": 7.2775423724078,
        "Timestamp": "2019-03-29T13:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-28T17:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.8750000003104,
        "Maximum": 13.8750000003104,
        "Timestamp": "2019-03-28T19:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-29T13:44:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T21:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333336438,
        "Maximum": 12.5208333336438,
        "Timestamp": "2019-03-28T22:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T17:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T21:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-28T23:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T10:12:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T11:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T08:26:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-28T18:19:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T18:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5208333328677,
        "Maximum": 12.5208333328677,
        "Timestamp": "2019-03-28T20:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T08:27:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-29T03:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.26041666682189,
        "Maximum": 6.26041666682189,
        "Timestamp": "2019-03-29T04:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T06:41:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916666356226,
        "Maximum": 0.447916666356226,
        "Timestamp": "2019-03-29T07:18:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T09:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 11.635416666201,
        "Maximum": 11.635416666201,
        "Timestamp": "2019-03-29T03:46:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.895833333488554,
        "Maximum": 0.895833333488554,
        "Timestamp": "2019-03-29T05:32:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.16666666635622,
        "Maximum": 7.16666666635622,
        "Timestamp": "2019-03-28T18:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T17:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T00:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 9.84375,
        "Maximum": 9.84375,
        "Timestamp": "2019-03-29T06:49:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.61458333348855,
        "Maximum": 7.61458333348855,
        "Timestamp": "2019-03-29T13:36:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.36458333333333,
        "Maximum": 5.36458333333333,
        "Timestamp": "2019-03-29T03:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T10:04:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333395422,
        "Maximum": 6.70833333395422,
        "Timestamp": "2019-03-28T19:56:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-28T23:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.96875,
        "Maximum": 12.96875,
        "Timestamp": "2019-03-29T12:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666660458,
        "Maximum": 12.9791666660458,
        "Timestamp": "2019-03-29T16:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T04:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T02:09:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T22:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.15778688539858,
        "Maximum": 6.15778688539858,
        "Timestamp": "2019-03-29T08:03:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7395833334886,
        "Maximum": 10.7395833334886,
        "Timestamp": "2019-03-28T17:55:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-28T22:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0729166665114,
        "Maximum": 12.0729166665114,
        "Timestamp": "2019-03-29T08:58:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15625000031044,
        "Maximum": 7.15625000031044,
        "Timestamp": "2019-03-29T12:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666697711,
        "Maximum": 4.91666666697711,
        "Timestamp": "2019-03-29T13:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T18:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.0833333333333,
        "Maximum": 12.0833333333333,
        "Timestamp": "2019-03-29T03:23:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T23:51:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.50000000015522,
        "Maximum": 8.50000000015522,
        "Timestamp": "2019-03-29T04:00:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T00:28:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.78125000015522,
        "Maximum": 1.78125000015522,
        "Timestamp": "2019-03-29T16:25:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T12:53:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.9791666668219,
        "Maximum": 12.9791666668219,
        "Timestamp": "2019-03-28T22:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4166666663562,
        "Maximum": 13.4166666663562,
        "Timestamp": "2019-03-29T02:17:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 1.34374999984478,
        "Maximum": 1.34374999984478,
        "Timestamp": "2019-03-29T02:54:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 12.5312499996896,
        "Maximum": 12.5312499996896,
        "Timestamp": "2019-03-29T17:02:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 5.81249999968956,
        "Maximum": 5.81249999968956,
        "Timestamp": "2019-03-29T13:30:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 10.7291666666667,
        "Maximum": 10.7291666666667,
        "Timestamp": "2019-03-29T14:07:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-28T23:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.447916667132328,
        "Maximum": 0.447916667132328,
        "Timestamp": "2019-03-29T08:13:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T11:45:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 4.91666666620101,
        "Maximum": 4.91666666620101,
        "Timestamp": "2019-03-28T23:59:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.60416666666667,
        "Maximum": 7.60416666666667,
        "Timestamp": "2019-03-29T12:22:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.05208333302289,
        "Maximum": 8.05208333302289,
        "Timestamp": "2019-03-29T08:50:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T21:37:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 13.4270833331781,
        "Maximum": 13.4270833331781,
        "Timestamp": "2019-03-28T18:05:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 0.881147541136282,
        "Maximum": 0.881147541136282,
        "Timestamp": "2019-03-29T03:31:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.70833333317811,
        "Maximum": 6.70833333317811,
        "Timestamp": "2019-03-28T22:14:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 8.052083333799,
        "Maximum": 8.052083333799,
        "Timestamp": "2019-03-28T18:42:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 6.71875,
        "Maximum": 6.71875,
        "Timestamp": "2019-03-29T04:08:00+00:00",
        "Unit": "Percent"
      },
      {
        "Average": 7.15624999953434,
        "Maximum": 7.15624999953434,
        "Timestamp": "2019-03-29T14:44:00+00:00",
        "Unit": "Percent"
      }
    ],
    "Label": "CPUUtilization",
    "MetricDescriptor": {
      "MetricLabel": "xxxxxx max CPU %",
      "YAxis": "left",
      "LabelColor": [
        0.5,
        0.5,
        1.0
      ],
      "Color": [
        0.66,
        0.66,
        1.0
      ],
      "MetricName": "CPUUtilization",
      "Namespace": "AWS/RDS",
      "Dimensions": [
        {
          "Name": "DBInstanceIdentifier",
          "Value": "xxxxxxxxxxxxxxxxxxx"
        }
      ],
      "Statistics": [
        "Average",
        "Maximum"
      ],
      "Unit": "Percent"
    }
  }
]